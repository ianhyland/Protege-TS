//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import org.protege.editor.owl.ui.action.ProtegeOWLAction;

public class Help extends ProtegeOWLAction {

	private static final long serialVersionUID = 1L;

	public void initialise() throws Exception { }

	public void dispose() throws Exception { }

	public void actionPerformed(ActionEvent arg0) {
		
		if (LicenceExpired.run()) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			return;
		}
		if (Config.firstRun) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			Config.firstRun = false;
		}
		
	    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(
	    		"Help Page: \n\n" +
				"Metrics                            Display the ontology and signature metrics \n" +
				"Results                            Display or do not display results of each operation (default is to display results) \n" +
				"Display                            Display keep or forget signature \n" +
				"Signature: \n" +
				"   Load                            Load signature from a file. Only enter the filename, the '.txt' extension will be added automatically \n" +
				"   Save                            Save signature to a file. Only enter the filename, the '.txt' extension will be added automatically \n" +
				"                                   Four files are saved for each of concept-keep, concept-forget, role-keep and role-forget \n" +
				"All                                Set all concepts and roles to either keep, forget or clear (blank) \n" +
				"Undefined                          Set any undefined concepts and roles to either keep or forget \n" +
				"Axioms (symbols)                   Include or do not include axioms (symbols) in the keep/forget signatures (default is do not include) \n" +
				"Entity                             Set a single concept or role to either keep or forget \n" +
				"Equivalent                         Set equivalent concepts or roles to either keep or forget \n" +
				"DownSet                            Set down set (subconcept/subrole) concepts or roles to either keep or forget \n" +
				"UpSet                              Set up set (superconcept/superrole) concepts or roles to either keep or forget \n" +
				"GCA                                Set general class axioms concepts or roles to either keep or forget \n" +
				"Equivalent Concepts: \n" +
				"   Include all                     Include all equivalent concepts in the keep/forget signature (this is the default) \n" +
				"   Include first only              Include only the first encountered equivalent concept in the keep/forget signature \n" +
				"Roles                              Set linked concepts and roles to either keep or forget. The number of hops is entered in subsequent the dialogue box \n" +
				"Command: \n" +
				"   Clear                           Clear the command log\n" +
				"   Load                            Load and execute the command log\n" +
				"   Save                            Save the command log\n" +
				"Help                               Display the help page (this page)"));
	}
}


//JOptionPane.showMessageDialog(getOWLWorkspace(), message.toString());
