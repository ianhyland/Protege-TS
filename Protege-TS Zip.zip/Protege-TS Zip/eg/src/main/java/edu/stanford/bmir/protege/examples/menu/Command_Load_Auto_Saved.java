//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class Command_Load_Auto_Saved {
	
	public static void run () {
				
		try {
			try {
				String commandFileName = "commandFileSavedAuto.txt";
				File commandFile = new File(commandFileName);
				FileReader frCommandFile = new FileReader(commandFile);
				BufferedReader brCommandFile = new BufferedReader(frCommandFile);
				String commandString = brCommandFile.readLine();
		        while (commandString != null) {
		        	Config.commandLog.add(commandString);
		        	commandString = brCommandFile.readLine();
		        }
		        brCommandFile.close();
			} catch (FileNotFoundException e) { System.out.println("Possible Eror: 'commandFileSavedAuto.txt' file not found"); }
		} catch (Exception e) { e.printStackTrace(); }
	}
}



//System.out.println ("dir = " + System.getProperty("user.dir"));