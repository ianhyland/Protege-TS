//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;


public class GCA_Command {
	
	public static void run (OWLOntology ontology, OWLOntologyManager manager, OWLDataFactory factory, OWLClass concept, OWLObjectProperty role, String tsString) {
					
		Term_Selection_Concept_Update_Annotation.run (ontology, manager, factory, concept, tsString);					//add selected concept
		
		Set<OWLClass> conceptsTemp = new HashSet<>();
		Set<OWLObjectProperty> rolesTemp = new HashSet<>();
		
		Set<OWLClassAxiom> generalClassAxioms = ontology.getGeneralClassAxioms();										//add general class axioms
		for (OWLClassAxiom generalClassAxiom : generalClassAxioms) {

			Set<OWLClassExpression> classExpressions = generalClassAxiom.getNestedClassExpressions();
			for (OWLClassExpression classExpression : classExpressions) {
				
				Set<OWLClass> conceptsCE = classExpression.getClassesInSignature();										//...concepts
				for (OWLClass concept1 : conceptsCE) {
					conceptsTemp.add(concept1);
				}
				Set<OWLObjectProperty> rolesCE = classExpression.getObjectPropertiesInSignature();						//...roles
				for (OWLObjectProperty role1 : rolesCE) {
					rolesTemp.add(role1);
				}
			}
			if (conceptsTemp.contains(concept)) {
				for (OWLClass concept1 : conceptsTemp) {
					Term_Selection_Concept_Update_Annotation.run (ontology, manager, factory, concept1, tsString);
				}
				for (OWLObjectProperty role1 : rolesTemp) {
					Term_Selection_Role_Update.run (ontology, manager, factory, role1, tsString);
				}
			}
 			conceptsTemp.clear();
 			rolesTemp.clear();	
 		}
	}
}
