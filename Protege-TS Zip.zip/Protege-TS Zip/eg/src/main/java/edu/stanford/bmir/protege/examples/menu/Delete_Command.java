//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.OWLAnnotation;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAxiom;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.parameters.Imports;
import org.semanticweb.owlapi.search.EntitySearcher;
import org.semanticweb.owlapi.util.OWLEntityRemover;

public class Delete_Command {
	
	public static void run (OWLOntology ontology, OWLOntologyManager manager, OWLDataFactory factory, Set<OWLClass> concepts, Set<OWLObjectProperty> roles, String tsString) {

		String tsStringConcept = "";
		String tsStringRole = "";	
		if (tsString.contentEquals(Config.tsKeep)) {
			tsStringConcept = Config.tsConceptKeep;
			tsStringRole = Config.tsRoleKeep;	
			
		} else {
			tsStringConcept = Config.tsConceptForget;
			tsStringRole = Config.tsRoleForget;	
		}
		
		Set<OWLAxiom> axiomsToRemove = new HashSet<OWLAxiom>();
		OWLEntityRemover remover = new OWLEntityRemover(Collections.singleton(ontology));

		for (OWLClass concept : concepts) {
			
			Collection<OWLAnnotation> annotations = EntitySearcher.getAnnotations(concept, ontology);
			for (OWLAnnotation annotation : annotations) {					

				if (annotation.getValue() instanceof OWLLiteral) {
					
					OWLLiteral literal = (OWLLiteral) annotation.getValue();
					String literalString = literal.getLiteral();
				
					if (literalString.contains(tsStringConcept)) {				
						Set<OWLClassAxiom> axioms = ontology.getAxioms(concept, Imports.INCLUDED);
						axiomsToRemove.addAll(axioms);
						remover.visit(concept);
					}
				}
			}		
		}		
		manager.removeAxioms(ontology, axiomsToRemove);
		manager.applyChanges(remover.getChanges());
		axiomsToRemove.clear();

		for (OWLObjectProperty role : roles) {
			
			Collection<OWLAnnotation> annotations = EntitySearcher.getAnnotations(role, ontology);
			for (OWLAnnotation annotation : annotations) {					
					
				if (annotation.getValue() instanceof OWLLiteral) {
			
					OWLLiteral literal = (OWLLiteral) annotation.getValue();
					String literalString = literal.getLiteral();
				
					if (literalString.contains(tsStringRole)) {				
	
						Set<OWLObjectPropertyAxiom> axioms = ontology.getAxioms(role, Imports.INCLUDED);
						axiomsToRemove.addAll(axioms);
						remover.visit(role);
					}
				}
			}		
		}
        manager.removeAxioms(ontology, axiomsToRemove);		
		manager.applyChanges(remover.getChanges());
	}
}
