//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.util.Collection;
import java.util.Set;

import org.semanticweb.owlapi.model.OWLAnnotation;
import org.semanticweb.owlapi.model.OWLClass;

import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.search.EntitySearcher;

public class Display {
	
	public Display () { }
	
	public static String run (OWLOntology ontology, String tsString) {
	
		Config.conceptsDisplay.clear();
		Set<OWLClass> concepts = ontology.getClassesInSignature();	
		for (OWLClass concept : concepts) {
			
			Collection<OWLAnnotation> annotations = EntitySearcher.getAnnotations(concept, ontology);

			for (OWLAnnotation annotation : annotations) {					
				
				if (annotation.getValue() instanceof OWLLiteral) {
					
					OWLLiteral literal = (OWLLiteral) annotation.getValue();
					String literalString = literal.getLiteral();
				
					if (literalString.contains(Config.tsConcept + tsString)) {
						Config.conceptsDisplay.add(concept);
					}
				}
			}
		}		
		
		Config.rolesDisplay.clear();
		Set<OWLObjectProperty> roles = ontology.getObjectPropertiesInSignature();	
		for (OWLObjectProperty role : roles) {
			
			Collection<OWLAnnotation> annotations = EntitySearcher.getAnnotations(role, ontology);

			for (OWLAnnotation annotation : annotations) {					
				
				if (annotation.getValue() instanceof OWLLiteral) {
					
					OWLLiteral literal = (OWLLiteral) annotation.getValue();
					String literalString = literal.getLiteral();
				
					if (literalString.contains(Config.tsRole + tsString)) {
						Config.rolesDisplay.add(role);
					}
				}	
			}
		}		
		
	    return DisplayString.run(tsString);
	}
}

