//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Set;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import org.protege.editor.owl.ui.action.ProtegeOWLAction;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

public class Command_Load extends ProtegeOWLAction {

	private static final long serialVersionUID = 1L;

	public void initialise() throws Exception { }

	public void dispose() throws Exception { }

	public void actionPerformed(ActionEvent arg0) {
		
		if (LicenceExpired.run()) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			return;
		}
		if (Config.firstRun) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			Config.firstRun = false;
		}
		
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		OWLDataFactory factory = getOWLDataFactory();
		OWLOntology ontology = getOWLModelManager().getActiveOntology();
		if (ontology.getClassesInSignature().size() == 0) {
		    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.errorFirstLoadAnOntologyString));
			return;
		}
		
		String pathMaster = "";
		String message = "";
		try {
			JFileChooser chooser = new JFileChooser();
			chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			int returnVal = chooser.showOpenDialog(null);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				pathMaster = chooser.getSelectedFile().getPath();
				message = "Command file loaded and executed: " + pathMaster + ".txt";

				try {
					String commandFileName = pathMaster + ".txt";
					File commandFile = new File(commandFileName);
					FileReader frCommandFile = new FileReader(commandFile);
					BufferedReader brCommandFile = new BufferedReader(frCommandFile);
					String commandString = brCommandFile.readLine();
			        while (commandString != null) {
			        	Config.commandLog.add(commandString);
			        	commandString = brCommandFile.readLine();
			        }
			        brCommandFile.close();
				} catch (FileNotFoundException e) { message = "Error: Command file not found: " + pathMaster + ".txt"; }
			}
		} catch (Exception e) { e.printStackTrace(); }
		
		for (String commandString : Config.commandLog) {
			String[] commandSplit = commandString.split(" ");
			String command = commandSplit[0];
			if (command.equals("All")) {
				String tsString = commandSplit[1];
				Set<OWLClass> concepts = getOWLModelManager().getActiveOntology().getClassesInSignature();
				Set<OWLObjectProperty> roles = getOWLModelManager().getActiveOntology().getObjectPropertiesInSignature();
				All_Command.run(ontology, manager, factory, concepts, roles, tsString);				
				if (Config.displayResults) System.out.println(command + " " + tsString + "\n");
			}
			if (command.equals("Delete")) {
				String tsString = commandSplit[1];
				Set<OWLClass> concepts = getOWLModelManager().getActiveOntology().getClassesInSignature();
				Set<OWLObjectProperty> roles = getOWLModelManager().getActiveOntology().getObjectPropertiesInSignature();
				Delete_Command.run(ontology, manager, factory, concepts, roles, tsString);
				if (Config.displayResults) System.out.println(command + " " + tsString + "\n");
			}
			if (command.equals("Undefined")) {
				String tsString = commandSplit[1];
				Set<OWLClass> concepts = getOWLModelManager().getActiveOntology().getClassesInSignature();
				Set<OWLObjectProperty> roles = getOWLModelManager().getActiveOntology().getObjectPropertiesInSignature();
				Undefined_Command.run(ontology, manager, factory, concepts, roles, tsString);
				if (Config.displayResults) System.out.println(command + " " + tsString + "\n");
			}
			if (command.equals("Entity")) {
				OWLClass concept = null;
				OWLObjectProperty role = null;
				String conceptRole = commandSplit[1];
				String tsString = commandSplit[2];
				String iri = commandSplit[3];
				if (conceptRole.equals("Concept")) {
					concept = factory.getOWLClass(IRI.create(iri));
					Term_Selection_Concept_Update.run (ontology, manager, factory, concept, tsString);
					if (Config.displayResults) System.out.println(command + " " + conceptRole + " " + tsString + " " + iri + "\n");
				} else {
					role = factory.getOWLObjectProperty(IRI.create(iri));
					Term_Selection_Role_Update.run (ontology, manager, factory, role, tsString);
					if (Config.displayResults) System.out.println(command + " " + conceptRole + " " + tsString + " " + iri + "\n");
				}
			}
			if (command.equals("DownSet")) {
				OWLClass concept = null;
				OWLObjectProperty role = null;
				String conceptRole = commandSplit[1];
				String tsString = commandSplit[2];
				String iri = commandSplit[3];
				if (conceptRole.equals("Concept")) {
					concept = factory.getOWLClass(IRI.create(iri));
				} else {
					role = factory.getOWLObjectProperty(IRI.create(iri));
				}
				DownSet_Command.run(ontology, manager, factory, concept, role, tsString);
				if (Config.displayResults) System.out.println(command + " " + conceptRole + " " + tsString + " " + iri + "\n");
			}
			if (command.equals("UpSet")) {
				OWLClass concept = null;
				OWLObjectProperty role = null;
				String conceptRole = commandSplit[1];
				String tsString = commandSplit[2];
				String iri = commandSplit[3];
				if (conceptRole.equals("Concept")) {
					concept = factory.getOWLClass(IRI.create(iri));
				} else {
					role = factory.getOWLObjectProperty(IRI.create(iri));
				}
				UpSet_Command.run(ontology, manager, factory, concept, role, tsString);
				if (Config.displayResults) System.out.println(command + " " + conceptRole + " " + tsString + " " + iri + "\n");
			}
			if (command.equals("Equivalent")) {
				OWLClass concept = null;
				OWLObjectProperty role = null;
				String conceptRole = commandSplit[1];
				String tsString = commandSplit[2];
				String iri = commandSplit[3];
				if (conceptRole.equals("Concept")) {
					concept = factory.getOWLClass(IRI.create(iri));
				} else {
					role = factory.getOWLObjectProperty(IRI.create(iri));
				}
				Equivalent_Command.run(ontology, manager, factory, concept, role, tsString);
				if (Config.displayResults) System.out.println(command + " " + conceptRole + " " + tsString + " " + iri + "\n");
			}
			if (command.equals("GCA")) {
				OWLClass concept = null;
				OWLObjectProperty role = null;
				String tsString = commandSplit[1];
				String iri = commandSplit[2];
				concept = factory.getOWLClass(IRI.create(iri));
				GCA_Command.run(ontology, manager, factory, concept, role, tsString);
				if (Config.displayResults) System.out.println(command + " " + tsString + " " + iri + "\n");
			}
			if (command.equals("Roles")) {
				OWLClass concept = null;
				String tsString = commandSplit[1];
				int roleLoopCount = Integer.parseInt(commandSplit[2]);
				String iri = commandSplit[3];
				concept = factory.getOWLClass(IRI.create(iri)); 
				Roles_Command.run(ontology, manager, factory, concept, tsString, roleLoopCount);
				if (Config.displayResults) System.out.println(command + " "  + tsString + " " + roleLoopCount + " " + iri + "\n");
			}
			if (command.equals("AxiomsInclude")) {
				Config.includeAxioms = true;
				if (Config.displayResults) System.out.println(command + "\n");
			}
			if (command.equals("AxiomsDoNotInclude")) {
				Config.includeAxioms = false;
				if (Config.displayResults) System.out.println(command + "\n");
			}
			if (command.equals("IncludeDefinedConcepts")) {
				Config.includeDefinedConcepts = true;
				if (Config.displayResults) System.out.println(command + "\n");
			}
			if (command.equals("IncludePrimitiveConcepts")) {
				Config.includeDefinedConcepts = false;
				if (Config.displayResults) System.out.println(command + "\n");
			}
			if (command.equals("DisplayResults")) {
				Config.displayResults = true;
				if (Config.displayResults) System.out.println(command + "\n");
			}
			if (command.equals("DoNotDisplayResults")) {
				if (Config.displayResults) System.out.println(command + "\n");
				Config.displayResults = false;
			}
		}
		
		if (Config.displayResults) {	
		    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(message));
		}
	}
}

/*
				System.out.println("4");
































*/

