//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Collection;
import java.util.Set;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import org.protege.editor.owl.ui.action.ProtegeOWLAction;
import org.semanticweb.owlapi.model.OWLAnnotation;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.search.EntitySearcher;

public class Signature_Save extends ProtegeOWLAction {

	private static final long serialVersionUID = 1L;

	public void initialise() throws Exception { }

	public void dispose() throws Exception { }

	public void actionPerformed(ActionEvent arg0) {

		if (LicenceExpired.run()) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			return;
		}
		if (Config.firstRun) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			Config.firstRun = false;
		}
		
		OWLOntology ontology = getOWLModelManager().getActiveOntology();
		if (ontology.getClassesInSignature().size() == 0) {
		    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.errorFirstLoadAnOntologyString));
			return;
		}		
		
		String pathMaster = "";
		int countKeepConceptsSignature = 0;
		int countForgetConceptsSignature = 0;
		int countKeepRolesSignature = 0;
		int countForgetRolesSignature = 0;
		
		try {
			JFileChooser chooser = new JFileChooser();
			chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			int returnVal = chooser.showOpenDialog(null);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				pathMaster = chooser.getSelectedFile().getPath();
				
				File fileConceptKeep = new File(pathMaster + "_Concept_Keep_Signature.txt");
				FileWriter fwConceptKeep = new FileWriter(fileConceptKeep);
				BufferedWriter bwConceptKeep = new BufferedWriter(fwConceptKeep);

				File fileConceptForget = new File(pathMaster + "_Concept_Forget_Signature.txt");
				FileWriter fwConceptForget = new FileWriter(fileConceptForget);
				BufferedWriter bwConceptForget = new BufferedWriter(fwConceptForget);
		
				Set<OWLClass> concepts = getOWLModelManager().getActiveOntology().getClassesInSignature();
				for (OWLClass concept : concepts) {	
					Collection<OWLAnnotation> annotations = EntitySearcher.getAnnotations(concept, ontology);
					for (OWLAnnotation annotation : annotations) {					
							
						if(annotation.getValue() instanceof OWLLiteral) {
							
							OWLLiteral literal = (OWLLiteral) annotation.getValue();
							String literalString = literal.getLiteral();
							if (literalString.contains(Config.tsConceptKeep)) {
//								bwConceptKeep.write(concept.getIRI().getShortForm() + "\n");
								bwConceptKeep.write(concept.getIRI() + "\n");
								countKeepConceptsSignature++;
							}
							if (literalString.contains(Config.tsConceptForget)) {
								bwConceptForget.write(concept.getIRI() + "\n");
								countForgetConceptsSignature++;
							}
						}
					}
				}

				bwConceptKeep.close();	
				bwConceptForget.close();

				File fileRoleKeep = new File(pathMaster + "_Role_Keep_Signature.txt");
				FileWriter fwRoleKeep = new FileWriter(fileRoleKeep);
				BufferedWriter bwRoleKeep = new BufferedWriter(fwRoleKeep);

				File fileRoleForget = new File(pathMaster + "_Role_Forget_Signature.txt");
				FileWriter fwRoleForget = new FileWriter(fileRoleForget);
				BufferedWriter bwRoleForget = new BufferedWriter(fwRoleForget);

				Set<OWLObjectProperty> roles = getOWLModelManager().getActiveOntology().getObjectPropertiesInSignature();
				for (OWLObjectProperty role : roles) {	
					Collection<OWLAnnotation> annotations = EntitySearcher.getAnnotations(role, ontology);
					for (OWLAnnotation annotation : annotations) {				
						
						if(annotation.getValue() instanceof OWLLiteral) {
							
							OWLLiteral literal = (OWLLiteral) annotation.getValue();
							String literalString = literal.getLiteral();
							if (literalString.contains(Config.tsRoleKeep)) {
								bwRoleKeep.write(role.getIRI() + "\n");
								countKeepRolesSignature++;
							}
							if (literalString.contains(Config.tsRoleForget)) {
								bwRoleForget.write(role.getIRI() + "\n");
								countForgetRolesSignature++;
							}
						}
					}
				}
				bwRoleKeep.close();	
				bwRoleForget.close();
			}
		} catch (Exception e) { e.printStackTrace(); }

		if (Config.displayResults) {
			
		    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(
		    		"Signature files saved:\n" +
				    "    " + pathMaster + "_Concept_Keep_Signature.txt\n" +
				    "    " + pathMaster + "_Role_Keep_Signature.txt\n" +
				    "    " + pathMaster + "_Concept_Forget_Signature.txt\n" +
				    "    " + pathMaster + "_Role_Keep_Signature.txt\n\n" +
				    
					"Keep concept signature: " + countKeepConceptsSignature + "\n" +
					"Keep role signature: " + countKeepRolesSignature + "\n" +
					"Forget concept signature: " + countForgetConceptsSignature + "\n" +
					"Forget role signature: " + countForgetRolesSignature + "\n\n" + 
		    		
	 				"Ontology metrics:\n\n" +
					"Axioms: " + getOWLModelManager().getActiveOntology().getAxiomCount() + "\n" +
					"Logical Axioms: " + getOWLModelManager().getActiveOntology().getLogicalAxiomCount() + "\n" +
					"Concepts: " + getOWLModelManager().getActiveOntology().getClassesInSignature().size() + "\n" +
					"Roles: " + getOWLModelManager().getActiveOntology().getObjectPropertiesInSignature().size() ));
		}
	}
}



//	"Ontology and signature metrics:\n\n" +
//"Axioms: " + getOWLModelManager().getActiveOntology().getAxiomCount() + "\n" );
//"Logical Axioms: " + getOWLModelManager().getActiveOntology().getLogicalAxiomCount() + "\n" +
//"Concepts: " + getOWLModelManager().getActiveOntology().getClassesInSignature().size() + "\n" +
//"Roles: " + getOWLModelManager().getActiveOntology().getObjectPropertiesInSignature().size(); 

//System.out.println("concept = " + concept.getIRI().getShortForm());

//System.out.println("annotation = " + annotation.getValue());

//------------------------------------
//Set<OWLLiteral> annotations = new HashSet<>();
//for (OWLAnnotation label : labelAnnotations) {
//		System.out.println("label = " + label.getValue());
//		annotations.add((OWLLiteral) label.getValue());
//-----------------------------------------------------------
//Stream<OWLAnnotation> annotations = getAnnotations(entity, ontology);
//for (OWLAnnotation annotation : annotations) {
//	System.out.println("annotation = " + annotation);
//}


//---------------------------------------------
//
//OWLOntology ontology = getOWLModelManager().getActiveOntology();
//System.out.println("ontology = " + ontology);
//
//Set<OWLClass> concepts = getOWLModelManager().getActiveOntology().getClassesInSignature();
//
//for (OWLClass concept : concepts) {
//	System.out.println("concept = " + concept.getIRI().getShortForm());
//	Set<OWLAnnotation> annotations = concept.getAnnotations(ontology);
//	for (OWLAnnotation annotation : annotations) {
//		System.out.println("annotation = " + annotation);
//	}
//}
//
//-----------------------------------------------

//StringBuilder message = new StringBuilder("Signature_Keep_All 13 ............................");		
//JOptionPane.showMessageDialog(getOWLWorkspace(), message.toString());
//
//Set<OWLClass> classes = getOWLModelManager().getActiveOntology().getClassesInSignature();
//
//for (OWLClass classA : classes) {
//	System.out.println("classA = " + classA.getIRI().getShortForm());
//}
//
//--------------------------------
//
//Set<OWLAnnotation> annotations = classA.getAnnotations(Config.getOntology());
//for (OWLAnnotation annotation : annotations) {
//	
//	OWLLiteral literal = (OWLLiteral) annotation.getValue();
//	String literalString = literal.getLiteral();
//
//	if (literalString.contains("]ts-")) {
//		Set<OWLAxiom> axiomsToRemove = new HashSet<OWLAxiom>();
//		OWLAxiom ax = Config.getFactory().getOWLAnnotationAssertionAxiom(classA.getIRI(), annotation);
//        axiomsToRemove.add(ax);
//        Config.getManager().removeAxioms(Config.getOntology(), axiomsToRemove);
//	}
//}
//String commentAnnoString = " ";
//if (ts.contains("forget")) { 
//	commentAnnoString = "]ts-individual-forget"; 
//}
//else { 
//	commentAnnoString = "]ts-individual-keep"; 
//}
//OWLAnnotation commentAnnotation = Config.getFactory().getOWLAnnotation(Config.getFactory().getRDFSComment(),
//		Config.getFactory().getOWLLiteral(commentAnnoString));
//OWLAxiom ax = Config.getFactory().getOWLAnnotationAssertionAxiom(classA.getIRI(), commentAnnotation);
//Config.getManager().applyChange(new AddAxiom(Config.getOntology(), ax));


