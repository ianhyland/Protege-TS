//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.util.Set;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

public class DownSet_Command {
	
	public static void run (OWLOntology ontology, OWLOntologyManager manager, OWLDataFactory factory, OWLClass concept, OWLObjectProperty role, String tsString) {
	
		OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
		OWLReasoner reasoner = reasonerFactory.createReasoner(ontology);

		if (!(concept == null)) {		
			Term_Selection_Concept_Update.run (ontology, manager, factory, concept, tsString);
			
		    NodeSet<OWLClass> subConceptsNodeSet = reasoner.getSubClasses(concept, false);
	        Set<OWLClass> subConcepts = subConceptsNodeSet.getFlattened();
		    
			for (OWLClass subConcept : subConcepts) {
				Term_Selection_Concept_Update.run (ontology, manager, factory, subConcept, tsString);
			}
		}	

		if (!(role == null)) {
			Term_Selection_Role_Update.run (ontology, manager, factory, role, tsString);

		    NodeSet<OWLObjectPropertyExpression> subRolesNodeSet = reasoner.getSubObjectProperties(role, false);
	        Set<OWLObjectPropertyExpression> subRoles = subRolesNodeSet.getFlattened();
		    
			for (OWLObjectPropertyExpression subRole : subRoles) {
				Term_Selection_Role_Update.run (ontology, manager, factory, subRole.asOWLObjectProperty(), tsString);
			}		
		}
	}
}
