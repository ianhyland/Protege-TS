//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import org.protege.editor.owl.ui.action.ProtegeOWLAction;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

public class Signature_Load extends ProtegeOWLAction {

	private static final long serialVersionUID = 1L;

	public void initialise() throws Exception { }

	public void dispose() throws Exception { }

	public void actionPerformed(ActionEvent arg0) {

		if (LicenceExpired.run()) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			return;
		}
		if (Config.firstRun) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			Config.firstRun = false;
		}
		
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		OWLDataFactory factory = getOWLDataFactory();
		OWLOntology ontology = getOWLModelManager().getActiveOntology();
		if (ontology.getClassesInSignature().size() == 0) {
		    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.errorFirstLoadAnOntologyString));
			return;
		}	

		String signatureFilesLoadedMessageOriginal = "Signature files loaded:";
		String signatureFilesLoadedMessage = signatureFilesLoadedMessageOriginal;
		String signatureFilesNotFoundErrorMessageOriginal = "Possible error: Signature file(s) not found:";
		String signatureFilesNotFoundErrorMessage = signatureFilesNotFoundErrorMessageOriginal;
		
		int countKeepConceptsSignature = 0;
		int countKeepRolesSignature = 0;
		int countForgetConceptsSignature = 0;
		int countForgetRolesSignature = 0;
		
		try {
			JFileChooser chooser = new JFileChooser();
			chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			int returnVal = chooser.showOpenDialog(null);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				String pathMaster = chooser.getSelectedFile().getPath();

				String fileName = "";
				try {
					fileName = pathMaster + "_Concept_Keep_Signature.txt";
					File file = new File(fileName);
					FileReader fr = new FileReader(file);
					BufferedReader br = new BufferedReader(fr);
					String signatureString = br.readLine();
			        while (signatureString != null) {
						OWLClass concept = factory.getOWLClass(IRI.create(signatureString));
						Term_Selection_Concept_Update_Annotation.run (ontology, manager, factory, concept, Config.tsKeep);
						countKeepConceptsSignature++;
						signatureString = br.readLine();
			        }
			        signatureFilesLoadedMessage = signatureFilesLoadedMessage + "\n   " + fileName;
			        br.close();
				} catch (FileNotFoundException e) { signatureFilesNotFoundErrorMessage = signatureFilesNotFoundErrorMessage + "\n   " + fileName; }

				try {
					fileName = pathMaster + "_Concept_Forget_Signature.txt";
					File file = new File(fileName);
					FileReader fr = new FileReader(file);
					BufferedReader br = new BufferedReader(fr);
					String signatureString = br.readLine();
			        while (signatureString != null) {	        	
						OWLClass concept = factory.getOWLClass(IRI.create(signatureString));
						Term_Selection_Concept_Update_Annotation.run (ontology, manager, factory, concept, Config.tsForget);
						countForgetConceptsSignature++;
						signatureString = br.readLine();
			        }
			        signatureFilesLoadedMessage = signatureFilesLoadedMessage + "\n   " + fileName;
			        br.close();
				} catch (FileNotFoundException e) { signatureFilesNotFoundErrorMessage = signatureFilesNotFoundErrorMessage + "\n   " + fileName; }

				try {
					fileName = pathMaster + "_Role_Keep_Signature.txt";
					File file = new File(fileName);
					FileReader fr = new FileReader(file);
					BufferedReader br = new BufferedReader(fr);
					String signatureString = br.readLine();
			        while (signatureString != null) {
						OWLObjectProperty role = factory.getOWLObjectProperty(IRI.create(signatureString));
						Term_Selection_Role_Update.run (ontology, manager, factory, role, Config.tsKeep);
						countKeepRolesSignature++;
						signatureString = br.readLine();
			        }
			        signatureFilesLoadedMessage = signatureFilesLoadedMessage + "\n   " + fileName;
			        br.close();
				} catch (FileNotFoundException e) { signatureFilesNotFoundErrorMessage = signatureFilesNotFoundErrorMessage + "\n   " + fileName; }
		        
				try {
					fileName = pathMaster + "_Role_Forget_Signature.txt";
					File file = new File(fileName);
					FileReader fr = new FileReader(file);
					BufferedReader br = new BufferedReader(fr);
					String signatureString = br.readLine();
			        while (signatureString != null) {
						OWLObjectProperty role = factory.getOWLObjectProperty(IRI.create(signatureString));
						Term_Selection_Role_Update.run (ontology, manager, factory, role, Config.tsForget);
						countForgetRolesSignature++;
						signatureString = br.readLine();
			        }
			        signatureFilesLoadedMessage = signatureFilesLoadedMessage + "\n   " + fileName;
			        br.close();
				} catch (FileNotFoundException e) { signatureFilesNotFoundErrorMessage = signatureFilesNotFoundErrorMessage + "\n   " + fileName; }
			}

		} catch (Exception e) { e.printStackTrace(); }

		if (signatureFilesLoadedMessage.contentEquals(signatureFilesLoadedMessageOriginal)) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block("Error: No signature files found"));
			return;
		}

		if (Config.displayResults) {
			
			if (signatureFilesNotFoundErrorMessage.contentEquals(signatureFilesNotFoundErrorMessageOriginal)) signatureFilesNotFoundErrorMessage = "";
			else signatureFilesNotFoundErrorMessage = signatureFilesNotFoundErrorMessage + "\n\n";
			
		    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(
		    		signatureFilesLoadedMessage + "\n\n" +
					signatureFilesNotFoundErrorMessage +
					"Ontology and signature metrics:\n\n" +
					"Axioms: " + getOWLModelManager().getActiveOntology().getAxiomCount() + "\n" +
					"Logical Axioms: " + getOWLModelManager().getActiveOntology().getLogicalAxiomCount() + "\n" +
					"Concepts: " + getOWLModelManager().getActiveOntology().getClassesInSignature().size() + "\n" +
					"Roles: " + getOWLModelManager().getActiveOntology().getObjectPropertiesInSignature().size() + "\n" +
					"Keep concepts signature: " + countKeepConceptsSignature + "\n" +
					"Keep roles signature: " + countKeepRolesSignature + "\n" +
					"Forget concepts signature: " + countForgetConceptsSignature + "\n" +
					"Forget roles signature: " + countForgetRolesSignature));
		}
		else {
			if (!signatureFilesNotFoundErrorMessage.contentEquals(signatureFilesNotFoundErrorMessageOriginal)) {
				JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(signatureFilesNotFoundErrorMessage));
			}
		}
	}
}

//commentAnnotation = factory.getOWLAnnotation(factory.getRDFSComment(),factory.getOWLLiteral(Config.tsConceptForget));
//OWLAxiom axiom = factory.getOWLAnnotationAssertionAxiom(concept.getIRI(), commentAnnotation);
//manager.addAxiom(ontology, axiom);
//manager.removeAxiom(ontology, axiom);
//
//commentAnnotation = factory.getOWLAnnotation(factory.getRDFSComment(),factory.getOWLLiteral(Config.tsConceptKeep));
//OWLAxiom ax = factory.getOWLAnnotationAssertionAxiom(concept.getIRI(), commentAnnotation);
//manager.applyChange(new AddAxiom(ontology, ax));

//commentAnnotation = factory.getOWLAnnotation(factory.getRDFSComment(),factory.getOWLLiteral(Config.tsConceptKeep));
//OWLAxiom axiom = factory.getOWLAnnotationAssertionAxiom(concept.getIRI(), commentAnnotation);
//manager.addAxiom(ontology, axiom);
//manager.removeAxiom(ontology, axiom);
//
//commentAnnotation = factory.getOWLAnnotation(factory.getRDFSComment(),factory.getOWLLiteral(Config.tsConceptForget));
//OWLAxiom ax = factory.getOWLAnnotationAssertionAxiom(concept.getIRI(), commentAnnotation);
//manager.applyChange(new AddAxiom(ontology, ax));

//commentAnnotation = factory.getOWLAnnotation(factory.getRDFSComment(),factory.getOWLLiteral(Config.tsRoleForget));
//OWLAxiom axiom = factory.getOWLAnnotationAssertionAxiom(role.getIRI(), commentAnnotation);
//manager.addAxiom(ontology, axiom);
//manager.removeAxiom(ontology, axiom);
//
//commentAnnotation = factory.getOWLAnnotation(factory.getRDFSComment(),factory.getOWLLiteral(Config.tsRoleKeep));
//OWLAxiom ax = factory.getOWLAnnotationAssertionAxiom(role.getIRI(), commentAnnotation);
//manager.applyChange(new AddAxiom(ontology, ax));

//commentAnnotation = factory.getOWLAnnotation(factory.getRDFSComment(),factory.getOWLLiteral(Config.tsRoleKeep));
//OWLAxiom axiom = factory.getOWLAnnotationAssertionAxiom(role.getIRI(), commentAnnotation);
//manager.addAxiom(ontology, axiom);
//manager.removeAxiom(ontology, axiom);
//
//commentAnnotation = factory.getOWLAnnotation(factory.getRDFSComment(),factory.getOWLLiteral(Config.tsRoleForget));
//OWLAxiom ax = factory.getOWLAnnotationAssertionAxiom(role.getIRI(), commentAnnotation);
//manager.applyChange(new AddAxiom(ontology, ax));


//Set<OWLObjectProperty> roles = ontology.getObjectPropertiesInSignature();
//for (OWLObjectProperty role : roles) {
//	if (role.getIRI().getShortForm().equals(signatureString)) {
//		OWLAxiom ax = factory.getOWLAnnotationAssertionAxiom(role.getIRI(), commentAnnotation);
//		manager.applyChange(new AddAxiom(ontology, ax));
//		break;
//	}		  
//}


//Set<OWLClass> concepts = ontology.getClassesInSignature();
//for (OWLClass concept : concepts) {
//	if (concept.getIRI().getShortForm().equals(signatureString)) {
//		OWLAxiom ax = factory.getOWLAnnotationAssertionAxiom(concept.getIRI(), commentAnnotation);
//		manager.applyChange(new AddAxiom(ontology, ax));
//		break;
//	}
//}



//System.out.println("concept = " + concept.getIRI().getShortForm());

//System.out.println("annotation = " + annotation.getValue());

//------------------------------------
//Set<OWLLiteral> annotations = new HashSet<>();
//for (OWLAnnotation label : labelAnnotations) {
//		System.out.println("label = " + label.getValue());
//		annotations.add((OWLLiteral) label.getValue());
//-----------------------------------------------------------
//Stream<OWLAnnotation> annotations = getAnnotations(entity, ontology);
//for (OWLAnnotation annotation : annotations) {
//	System.out.println("annotation = " + annotation);
//}


//---------------------------------------------
//
//OWLOntology ontology = getOWLModelManager().getActiveOntology();
//System.out.println("ontology = " + ontology);
//
//Set<OWLClass> concepts = getOWLModelManager().getActiveOntology().getClassesInSignature();
//
//for (OWLClass concept : concepts) {
//	System.out.println("concept = " + concept.getIRI().getShortForm());
//	Set<OWLAnnotation> annotations = concept.getAnnotations(ontology);
//	for (OWLAnnotation annotation : annotations) {
//		System.out.println("annotation = " + annotation);
//	}
//}
//
//-----------------------------------------------

//StringBuilder message = new StringBuilder("Signature_Keep_All 13 ............................");		
//JOptionPane.showMessageDialog(getOWLWorkspace(), message.toString());
//
//Set<OWLClass> classes = getOWLModelManager().getActiveOntology().getClassesInSignature();
//
//for (OWLClass classA : classes) {
//	System.out.println("classA = " + classA.getIRI().getShortForm());
//}
//
//--------------------------------
//
//Set<OWLAnnotation> annotations = classA.getAnnotations(Config.getOntology());
//for (OWLAnnotation annotation : annotations) {
//	
//	OWLLiteral literal = (OWLLiteral) annotation.getValue();
//	String literalString = literal.getLiteral();
//
//	if (literalString.contains("]ts-")) {
//		Set<OWLAxiom> axiomsToRemove = new HashSet<OWLAxiom>();
//		OWLAxiom ax = Config.getFactory().getOWLAnnotationAssertionAxiom(classA.getIRI(), annotation);
//        axiomsToRemove.add(ax);
//        Config.getManager().removeAxioms(Config.getOntology(), axiomsToRemove);
//	}
//}
//String commentAnnoString = " ";
//if (ts.contains("forget")) { 
//	commentAnnoString = "]ts-individual-forget"; 
//}
//else { 
//	commentAnnoString = "]ts-individual-keep"; 
//}
//OWLAnnotation commentAnnotation = Config.getFactory().getOWLAnnotation(Config.getFactory().getRDFSComment(),
//		Config.getFactory().getOWLLiteral(commentAnnoString));
//OWLAxiom ax = Config.getFactory().getOWLAnnotationAssertionAxiom(classA.getIRI(), commentAnnotation);
//Config.getManager().applyChange(new AddAxiom(Config.getOntology(), ax));


