//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.util.ArrayList;
import java.util.Collections;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLObjectProperty;

public class DisplayString {
	
	public DisplayString () { }
	
	public static String run (String tsString) {

		String displayString = "";
		ArrayList<String> arrayString = new ArrayList<String>();
		int largestSignatureSize = 300;
		
		displayString = "Added to Concepts " + tsString + " signature (total " + Config.conceptsDisplay.size() + "):\n";
		if (Config.conceptsDisplay.size() > largestSignatureSize) {
			displayString =  displayString + "Signature too large to display\n" +
							 				 "Suggest saving signature to a file using 'Signature - Save'\n";
		}
		else {
			for (OWLClass concept : Config.conceptsDisplay) {
				arrayString.add(concept.getIRI().getShortForm());
			}
		    Collections.sort(arrayString);
		    for (String concept : arrayString) {
		    	displayString = displayString + concept + "\n";
		    }
		}

		displayString = displayString + "\nAdded to Roles " + tsString + " signature (total " + Config.rolesDisplay.size() + "):\n";
		if (Config.rolesDisplay.size() > largestSignatureSize) {
			displayString = displayString + "Signature too large to display\n" +
							 				"Suggest saving signature to a file using 'Signature - Save'";
		}
		else {
		    arrayString = new ArrayList<String>();
			for (OWLObjectProperty role : Config.rolesDisplay) {
				arrayString.add(role.getIRI().getShortForm());
			}
		    Collections.sort(arrayString);
		    for (String role : arrayString) {
		    	displayString = displayString + role + "\n";
		    }
		}

	    return displayString;
	}
}
