//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import org.protege.editor.owl.ui.action.ProtegeOWLAction;

public class IncludeAxiomsDoNot extends ProtegeOWLAction {

	private static final long serialVersionUID = 1L;

	public void initialise() throws Exception { }

	public void dispose() throws Exception { }

	public void actionPerformed(ActionEvent arg0) {		
		
		if (LicenceExpired.run()) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			return;
		}
		if (Config.firstRun) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			Config.firstRun = false;
		}
		
		Config.includeAxioms = false;
		Config.commandLog.add ("AxiomsDoNotInclude");

		if (Config.displayResults) {
		    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block("Do not include axioms in the keep/forget signatures"));
		}
	}
}



//System.out.println("concept = " + concept.getIRI().getShortForm());
//System.out.println("annotation = " + annotation.getValue());
//System.out.println("string = " + string);

//------------------------------------
//Set<OWLLiteral> annotations = new HashSet<>();
//for (OWLAnnotation label : labelAnnotations) {
//		System.out.println("label = " + label.getValue());
//		annotations.add((OWLLiteral) label.getValue());
//-----------------------------------------------------------
//Stream<OWLAnnotation> annotations = getAnnotations(entity, ontology);
//for (OWLAnnotation annotation : annotations) {
//	System.out.println("annotation = " + annotation);
//}


//---------------------------------------------
//
//OWLOntology ontology = getOWLModelManager().getActiveOntology();
//System.out.println("ontology = " + ontology);
//
//Set<OWLClass> concepts = getOWLModelManager().getActiveOntology().getClassesInSignature();
//
//for (OWLClass concept : concepts) {
//	System.out.println("concept = " + concept.getIRI().getShortForm());
//	Set<OWLAnnotation> annotations = concept.getAnnotations(ontology);
//	for (OWLAnnotation annotation : annotations) {
//		System.out.println("annotation = " + annotation);
//	}
//}
//
//-----------------------------------------------

//StringBuilder message = new StringBuilder("Signature_Keep_All 13 ............................");		
//JOptionPane.showMessageDialog(getOWLWorkspace(), message.toString());
//
//Set<OWLClass> classes = getOWLModelManager().getActiveOntology().getClassesInSignature();
//
//for (OWLClass classA : classes) {
//	System.out.println("classA = " + classA.getIRI().getShortForm());
//}
//
//--------------------------------
//
//Set<OWLAnnotation> annotations = classA.getAnnotations(Config.getOntology());
//for (OWLAnnotation annotation : annotations) {
//	
//	OWLLiteral literal = (OWLLiteral) annotation.getValue();
//	String literalString = literal.getLiteral();
//
//	if (literalString.contains("]ts-")) {
//		Set<OWLAxiom> axiomsToRemove = new HashSet<OWLAxiom>();
//		OWLAxiom ax = Config.getFactory().getOWLAnnotationAssertionAxiom(classA.getIRI(), annotation);
//        axiomsToRemove.add(ax);
//        Config.getManager().removeAxioms(Config.getOntology(), axiomsToRemove);
//	}
//}
//String commentAnnoString = " ";
//if (ts.contains("forget")) { 
//	commentAnnoString = "]ts-individual-forget"; 
//}
//else { 
//	commentAnnoString = "]ts-individual-keep"; 
//}
//OWLAnnotation commentAnnotation = Config.getFactory().getOWLAnnotation(Config.getFactory().getRDFSComment(),
//		Config.getFactory().getOWLLiteral(commentAnnoString));
//OWLAxiom ax = Config.getFactory().getOWLAnnotationAssertionAxiom(classA.getIRI(), commentAnnotation);
//Config.getManager().applyChange(new AddAxiom(Config.getOntology(), ax));


