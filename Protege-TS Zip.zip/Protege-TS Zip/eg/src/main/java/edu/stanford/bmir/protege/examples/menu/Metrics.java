//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.Set;

import javax.swing.JOptionPane;

import org.protege.editor.owl.ui.action.ProtegeOWLAction;
import org.semanticweb.owlapi.model.OWLAnnotation;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.search.EntitySearcher;

public class Metrics extends ProtegeOWLAction {

	private static final long serialVersionUID = 1L;

	public void initialise() throws Exception { }

	public void dispose() throws Exception { }

	public void actionPerformed(ActionEvent arg0) {
		
		if (LicenceExpired.run()) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			return;
		}
		if (Config.firstRun) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			Config.firstRun = false;
		}
		
		OWLOntology ontology = getOWLModelManager().getActiveOntology();
		int ontologyCount = ontology.getClassesInSignature().size();
		if (ontologyCount == 0) {
		    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.errorFirstLoadAnOntologyString));
			return;
		}
		
		int countConceptsKeepSignature = 0;
		int countConceptsForgetSignature = 0;
		Set<OWLClass> concepts = ontology.getClassesInSignature();
		for (OWLClass concept : concepts) {
			
			Collection<OWLAnnotation> annotations = EntitySearcher.getAnnotations(concept, ontology);
			for (OWLAnnotation annotation : annotations) {					
				
				if (annotation.getValue() instanceof OWLLiteral) {
					
					OWLLiteral literal = (OWLLiteral) annotation.getValue();
					String literalString = literal.getLiteral();

					if (literalString.contains(Config.tsConceptKeep)) countConceptsKeepSignature++;
					if (literalString.contains(Config.tsConceptForget)) countConceptsForgetSignature++;					
				}
			}
		}

		int countRolesKeepSignature = 0;
		int countRolesForgetSignature = 0;
		Set<OWLObjectProperty> roles = ontology.getObjectPropertiesInSignature();
		for (OWLObjectProperty role : roles) {
			
			Collection<OWLAnnotation> annotations = EntitySearcher.getAnnotations(role, ontology);
			for (OWLAnnotation annotation : annotations) {

				if (annotation.getValue() instanceof OWLLiteral) {

					OWLLiteral literal = (OWLLiteral) annotation.getValue();
					String literalString = literal.getLiteral();
	
					if (literalString.contains(Config.tsRoleKeep)) countRolesKeepSignature++;
					if (literalString.contains(Config.tsRoleForget)) countRolesForgetSignature++;
				}
			}
		}
		
	    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(
	    		"Ontology and signature metrics:\n\n" +
				"Axioms: " + getOWLModelManager().getActiveOntology().getAxiomCount() + "\n" +
				"Logical Axioms: " + getOWLModelManager().getActiveOntology().getLogicalAxiomCount() + "\n" +
				"Concepts: " + getOWLModelManager().getActiveOntology().getClassesInSignature().size() + "\n" +
				"Roles: " + getOWLModelManager().getActiveOntology().getObjectPropertiesInSignature().size() + "\n" +
				"Keep concepts signature: " + countConceptsKeepSignature + "\n" +
				"Keep roles signature: " + countRolesKeepSignature + "\n" +
				"Forget concepts signature: " + countConceptsForgetSignature + "\n" +
				"Forget roles signature: " + countRolesForgetSignature + "\n"));  
	}
}

