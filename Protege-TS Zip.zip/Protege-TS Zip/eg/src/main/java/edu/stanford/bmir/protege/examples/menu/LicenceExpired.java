//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

public class LicenceExpired {
	
	public LicenceExpired () { }
	
	public static boolean run () {
				
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());

		int dayNow = calendar.get(Calendar.DAY_OF_MONTH);
		int monthNow = calendar.get(Calendar.MONTH);
		monthNow++;
		int yearNow = calendar.get(Calendar.YEAR);

		LocalDate dateNow = LocalDate.of(yearNow, monthNow, dayNow);
		LocalDate dateLicence = LocalDate.of(Config.yearLicence, Config.monthLicence, Config.dayLicence);
		
		if (dateNow.isAfter(dateLicence)) return true;
		else return false;
	}
}

