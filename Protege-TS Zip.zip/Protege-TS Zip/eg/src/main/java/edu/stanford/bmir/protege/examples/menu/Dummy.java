//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import org.protege.editor.owl.ui.action.ProtegeOWLAction;

public class Dummy extends ProtegeOWLAction {

	private static final long serialVersionUID = 1L;

	public void initialise() throws Exception { }

	public void dispose() throws Exception { }

	public void actionPerformed(ActionEvent arg0) {
		
	    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block("Error: Dummy method"));
	 	 
	}
}



//System.out.println("dummy ................");

//String jarFilePath = "C://Users//ianhy//Documents//A.jar";
//String[] args = null;
//new JarExecutor.executeJar();			
	
//try {
//	
//    Process ps=Runtime.getRuntime().exec(new String[]{"java","-jar","C://Users//ianhy//Documents//A.jar"});
//    try {
//		ps.waitFor();
//	}
//    catch (InterruptedException e) { e.printStackTrace(); }
//    
//    java.io.InputStream is = ps.getInputStream();
//    byte b[]=new byte[is.available()];
//    is.read(b,0,b.length);
//    System.out.println(new String(b));
//    
////    Process proc;
////	proc = Runtime.getRuntime().exec("java -jar C://Users//ianhy//Documents//A.jar");
////	
////	System.out.println("dummy 222222222 ................");
////	
////	InputStream in = proc.getInputStream();
////	InputStream err = proc.getErrorStream();
//	 
//} catch (IOException e) { e.printStackTrace(); }	 // Then retreive the process output
