//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLObjectProperty;

public class Config {

	public static String tsKeep =           "Keep";
	public static String tsForget =         "Forget";
	public static String tsClear =          "Clear";
	public static String ts =               "]-Term-Selection-";
	public static String tsConcept =        "]-Term-Selection-Concept-";
	public static String tsConceptKeep =    "]-Term-Selection-Concept-Keep";
	public static String tsConceptForget =  "]-Term-Selection-Concept-Forget"; 
	public static String tsRole =           "]-Term-Selection-Role-"; 
	public static String tsRoleKeep =       "]-Term-Selection-Role-Keep";
	public static String tsRoleForget =     "]-Term-Selection-Role-Forget";
	
	public static String errorFirstLoadAnOntologyString = "Error: First load an ontology";
	public static String errorFirstSelectAConceptOrRoleString = "Error: First select a concept or role";
	public static String errorFirstSelectAConceptString = "Error: First select a concept";
	
	public static int maxRoleLoopCount = 8;
	public static String errorNumberOfHopsString = "Error: The number of role hops is an integer between 1 and " + String.valueOf(maxRoleLoopCount);
	
	public static boolean displayResults = true;
	public static boolean includeAxioms = false;
	public static boolean includeDefinedConcepts = true;
	
	public static Set<OWLClass> conceptsDisplay = new HashSet<>();
	public static Set<OWLObjectProperty> rolesDisplay = new HashSet<>();
	
	public static ArrayList<String> commandLog = new ArrayList<String>();
	
	public static int yearLicence = 2020;
	public static int monthLicence = 12;
	private static String monthLicenceString = "December";
	public static int dayLicence = 31;
	
	public static boolean firstRun = true;
	public static String firstRunMessage = 
			   	"This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.\n" +
			   	"\n" +
			   	"This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by\n" +
			   	"the Free Software Foundation, either version 3 of the License, or any later version.\n" +
			   	"\n" +
			   	"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of\n" +
			   	"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.\n" +
			   	"\n" +
			   	"You should have received a copy of the GNU General Public License along with this program.  If not, see <https://www.gnu.org/licenses/>.\n" +
			   	"\n" +
			   	"Please contact  ianhyland@ngensys.com  on or before " + dayLicence + " " + monthLicenceString + " " + yearLicence + " with any support queries.";
}


//System.exit(0)