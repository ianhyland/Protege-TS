//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.parameters.Imports;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

public class Roles {
	
	public Roles () { }
			
	public static String run (OWLOntology ontology, OWLOntologyManager manager, OWLDataFactory factory,
							  OWLClass conceptStart, String tsString, int roleLoopCount) {	
					
		OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
		OWLReasoner reasoner = reasonerFactory.createReasoner(ontology);
		
		String conceptString = conceptStart.toString().substring(1, conceptStart.toString().length() - 1);
		Config.commandLog.add ("Roles " + tsString + " " + roleLoopCount + " " + conceptString);
		
		Set<OWLClass> concepts = new HashSet<>();
		Set<OWLClass> conceptsNextLoop = new HashSet<>();
		
		Config.conceptsDisplay.clear();
		Config.rolesDisplay.clear();
		
		concepts.add(conceptStart);
		for (int i=1; i<=roleLoopCount; i++) {
			
			for (OWLClass concept : concepts) {
				
				Term_Selection_Concept_Update_Annotation.run (ontology, manager, factory, concept, tsString); 
				conceptsNextLoop.remove(concept);
				Set<OWLClassAxiom> axioms = ontology.getAxioms(concept, Imports.EXCLUDED);
				for (OWLClassAxiom axiom : axioms) {
					
					Set<OWLClassExpression> conceptExpressions = axiom.getNestedClassExpressions();
					for (OWLClassExpression conceptExpression : conceptExpressions) {

						Set<OWLClass> conceptsExpression = conceptExpression.getClassesInSignature();
						Set<OWLObjectProperty> roles = conceptExpression.getObjectPropertiesInSignature();
						
						for (OWLClass conceptExpression1 : conceptsExpression) {		

							conceptsNextLoop.add(conceptExpression1);
							if (Config.includeDefinedConcepts) {
								Term_Selection_Concept_Update_Annotation.run (ontology, manager, factory, conceptExpression1, tsString);
								for (OWLObjectProperty role : roles) {
									Term_Selection_Role_Update.run (ontology, manager, factory, role.asOWLObjectProperty(), tsString);							
								}
							}
							else {								
							    Node<OWLClass> equivalentConceptNodeClasses = reasoner.getEquivalentClasses(concept);
							    Set<OWLClass> equivalentConceptsSet = equivalentConceptNodeClasses.getEntitiesMinus(concept);
							    for (OWLClass equivalentConcept : equivalentConceptsSet) {
							    	conceptsNextLoop.remove(equivalentConcept);
							    }					
							    for (OWLClass concept1 : conceptsNextLoop) {
									Term_Selection_Concept_Update_Annotation.run (ontology, manager, factory, concept1, tsString);
									for (OWLObjectProperty role : roles) {
										Term_Selection_Role_Update.run (ontology, manager, factory, role.asOWLObjectProperty(), tsString);							
									}
							    }
							}
						}
					}
				}
			}
			concepts.clear();
			concepts.addAll(conceptsNextLoop);
			conceptsNextLoop.clear();
		}
					
	    return DisplayString.run(tsString);
	}	
}
/*

						System.out.println("conceptsExpression" + conceptsExpression);
						
						======================================
					    
					    Boolean isEquivalentConcept = false;
						for (OWLClass equivalentConcept : equivalentConcepts) {
							if ( !(equivalentConcept == null) ) isEquivalentConcept = true;	
						}
								conceptsEquivalentSet.add(equivalentConcept);
								for (OWLClass conceptEquivalent : conceptsEquivalentSet) {

								}
							}
							else {
 
		for (OWLClass concept1 : Config.getConceptsDisplay()) {
			if (!Config.getClassIncludeDefined() && conceptsEquivalentSet.contains(concept1)) {
			}
			else {
				Term_Selection_Concept_Update.run (ontology, manager, factory, concept1, tsString);
			}
		}

		for (OWLObjectProperty role1 : Config.getRolesDisplay()) {
			Term_Selection_Role_Update.run (ontology, manager, factory, role1, tsString);
		}
-------------------------------------------
		conceptsAll = ontology.getClassesInSignature();
		for (OWLClass concept2 : conceptsAll) {
			System.out.println("\nconcept2 = " + concept2);
		}
		
------------------------------------
static int	getArity(org.semanticweb.owlapi.model.OWLClassExpression ce)
Returns the arity of a class expression.

            if (entity.isOWLClass()) {                axioms = ont.getAxioms(entity.asOWLClass());            } else if (entity.isOWLObjectProperty()) {                axioms = ont.getAxioms(entity.asOWLObjectProperty()); 
            
                  public void visit(OWLSubClassOfAxiom axiom) {           
                   if (!axiom.getSubClass().isAnonymous()) {                
                  getAxiomsForLHS(axiom.getSubClass().asOWLClass()).add(axiom);                
                  indexAxiomsByRHSEntities(axiom.getSuperClass(), axiom);            }        }
---------------------------------------

					Set<OWLClassAxiom> axioms = ontology.getAxioms(concept, Imports.EXCLUDED);
					for (OWLClassAxiom axiom : axioms) {
						System.out.println("\n axiom = " + axiom);
---------------------------------------
//				if (classExpression instanceof OWLObjectSomeValuesFrom) {
//					
//				}
//				if(classExpression.getClassExpressionType().equals(ClassExpressionType.OBJECT_SOME_VALUES_FROM) ) {
//					OWLObjectSomeValuesFrom all = (OWLObjectSomeValuesFrom) classExpression;
//					System.out.println("all getFiller() = " + all.getFiller());
//					System.out.println("all getProperty() = " + all.getProperty());
//				
//				}
 
//		if (x instanceof OWLObjectIntersectionOf)
					
//		if (superClass.getClassExpressionType() == ClassExpressionType.OBJECT_SOME_VALUES_FROM)
					
//java.util.Set<OWLSubClassAxiom> getSubClassAxiomsForLHS(OWLClass cls)
					
//		int i = conceptsDisplay.size();
				
//				    Node<OWLClass> equivalentConceptNodeClasses = reasoner.getEquivalentClasses(conceptNextSet);
//				    Set<OWLClass> equivalentConcepts = equivalentConceptNodeClasses.getEntitiesMinus(conceptNextSet);
//				    
//					for (OWLClass equivalentConcept : equivalentConcepts) {															//add equivalent concepts
//						new Term_Selection_Concept_Update (ontology, manager, factory, equivalentConcept, tsString);
//						conceptsDisplay.add(equivalentConcept);
//						conceptsNextSetTemp.add(equivalentConcept);
//						System.out.println("equivalentConcept = " + equivalentConcept);
//					}
//					
//					Set<OWLEquivalentClassesAxiom> equivalentClassesAxioms = ontology.getEquivalentClassesAxioms(concept);			//add equivalent axioms
//					for (OWLEquivalentClassesAxiom equivalentClassesAxiom : equivalentClassesAxioms) {
//						
//						Set<OWLClassExpression> classExpressions = equivalentClassesAxiom.getClassExpressions();
//						for (OWLClassExpression classExpression : classExpressions) {
//						
//						    Set<OWLClass> concepts = classExpression.getClassesInSignature();										//...concepts
//							for (OWLClass concept1 : concepts) {
//								new Term_Selection_Concept_Update (ontology, manager, factory, concept1, tsString);
//								conceptsDisplay.add(concept1);
//								conceptsNextSetTemp.add(concept1);
//								System.out.println("eq ax concept1 = " + concept1);
//							}
//							Set<OWLObjectProperty> roles = classExpression.getObjectPropertiesInSignature();						//...roles
//							for (OWLObjectProperty role1 : roles) {
//							    if (!role1.asOWLObjectProperty().getIRI().getShortForm().contentEquals("topObjectProperty")) {
//								    new Term_Selection_Role_Update (ontology, manager, factory, role1, tsString);
//									rolesDisplay.add(role1);
//									System.out.println("eq ax role1 = " + role1);
//								}
//							}
//						}
//					}
//					
//					Set<OWLClassAxiom> generalClassAxioms = ontology.getGeneralClassAxioms();										//add general class axioms
//					for (OWLClassAxiom generalClassAxiom : generalClassAxioms) {
//					
//						Set<OWLClassExpression> classExpressions = generalClassAxiom.getNestedClassExpressions();
//						for (OWLClassExpression classExpression : classExpressions) {
//						
//							Set<OWLClass> conceptsCE = classExpression.getClassesInSignature();										//...concepts
//							for (OWLClass concept1 : conceptsCE) {
//								conceptsTemp.add(concept1);
//							}
//
//							Set<OWLObjectProperty> rolesCE = classExpression.getObjectPropertiesInSignature();						//...roles
//							for (OWLObjectProperty role1 : rolesCE) {
//								new Term_Selection_Role_Update (ontology, manager, factory, role1, tsString);
//								rolesTemp.add(role1);
//							}
//						}
//						if (conceptsTemp.contains(conceptNextSet)) {
//							for (OWLClass concept1 : conceptsTemp) {
//								new Term_Selection_Concept_Update (ontology, manager, factory, concept1, tsString);
//								conceptsDisplay.add(concept1);
//								conceptsNextSetTemp.add(concept1);
//								System.out.println("gca concept1 = " + concept1);
//							}
//							for (OWLObjectProperty role1 : rolesTemp) {
//								new Term_Selection_Role_Update (ontology, manager, factory, role1, tsString);
//								rolesDisplay.add(role1);
//								System.out.println("gca role1 = " + role1);
//							}
//						}
//			 			conceptsTemp.clear();
//			 			rolesTemp.clear();
//					}
//				}
//			}
//		}

--------------------------------------------------------------------------------------
			new Term_Selection_Concept_Update (ontology, manager, factory, concept, tsString);								//add selected concept
			conceptsDisplay.add(concept);

			Set<OWLClassAxiom> generalClassAxioms = ontology.getGeneralClassAxioms();
			for (OWLClassAxiom generalClassAxiom : generalClassAxioms) {
				System.out.println("\n ---------------------------------------- \n");// generalClassAxiom = " + generalClassAxiom);
			
				Set<OWLClassExpression> classExpressions = generalClassAxiom.getNestedClassExpressions();
				for (OWLClassExpression classExpression : classExpressions) {
				
					Set<OWLClass> conceptsCE = classExpression.getClassesInSignature();										//...concepts
					for (OWLClass concept1 : conceptsCE) {
						conceptsTemp.add(concept1);
					}

					Set<OWLObjectProperty> rolesCE = classExpression.getObjectPropertiesInSignature();						//...roles
					for (OWLObjectProperty role1 : rolesCE) {

						new Term_Selection_Role_Update (ontology, manager, factory, role1, tsString);
						rolesTemp.add(role1);
					}
				}
				if (conceptsTemp.contains(concept)) {
					for (OWLClass concept1 : conceptsTemp) {
						new Term_Selection_Concept_Update (ontology, manager, factory, concept1, tsString);
						conceptsDisplay.add(concept1);
					}
					for (OWLObjectProperty role1 : rolesTemp) {
						new Term_Selection_Role_Update (ontology, manager, factory, role1, tsString);
						rolesDisplay.add(role1);
					}
				}
	 			conceptsTemp.clear();
	 			rolesTemp.clear();



=================================================
		if (!(role == null)) {
			
			new Term_Selection_Role_Update (ontology, manager, factory, role, tsString);									//add selected role
			rolesDisplay.add(role);
			
			OWLObjectPropertyExpression rolePropertyExpression = (OWLObjectPropertyExpression)role;							//add equivalent roles
			Node<OWLObjectPropertyExpression> rolePropertyExpressionNode = reasoner.getEquivalentObjectProperties(rolePropertyExpression);
			
			for (OWLObjectPropertyExpression rolePropertyExpression1 : rolePropertyExpressionNode) {
				
				OWLObjectProperty role2 = (OWLObjectProperty)rolePropertyExpression1;
				new Term_Selection_Role_Update (ontology, manager, factory, role2, tsString);
				  rolesDisplay.add(role2);
			}
		}
	
	*/