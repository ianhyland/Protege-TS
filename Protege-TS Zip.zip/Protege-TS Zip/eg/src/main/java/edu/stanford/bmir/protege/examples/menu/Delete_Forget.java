//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.swing.JOptionPane;

import org.protege.editor.owl.ui.action.ProtegeOWLAction;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLAnnotation;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAxiom;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.parameters.Imports;
import org.semanticweb.owlapi.search.EntitySearcher;
import org.semanticweb.owlapi.util.OWLEntityRemover;

public class Delete_Forget extends ProtegeOWLAction {

	private static final long serialVersionUID = 1L;

	public void initialise() throws Exception { }

	public void dispose() throws Exception { }

	public void actionPerformed(ActionEvent arg0) {
		
		Config.commandLog.add ("Delete " + Config.tsForget);
		
		String tsStringConcept = Config.tsConceptForget;
		String tsStringRole = Config.tsRoleForget;
		
		if (LicenceExpired.run()) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			return;
		}
		if (Config.firstRun) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			Config.firstRun = false;
		}
		
		Config.conceptsDisplay.clear();
		Config.rolesDisplay.clear();
		
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		OWLOntology ontology = getOWLModelManager().getActiveOntology();
		if (ontology.getClassesInSignature().size() == 0) {
		    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.errorFirstLoadAnOntologyString));
			return;
		}		
		
		Set<OWLAxiom> axiomsToRemove = new HashSet<OWLAxiom>();
		OWLEntityRemover remover = new OWLEntityRemover(Collections.singleton(ontology));
		Set<OWLClass> concepts = getOWLModelManager().getActiveOntology().getClassesInSignature();
		for (OWLClass concept : concepts) {
			
			Collection<OWLAnnotation> annotations = EntitySearcher.getAnnotations(concept, ontology);

			for (OWLAnnotation annotation : annotations) {					

				if (annotation.getValue() instanceof OWLLiteral) {
					
					OWLLiteral literal = (OWLLiteral) annotation.getValue();
					String literalString = literal.getLiteral();
				
					if (literalString.contains(tsStringConcept)) {				
		
						Set<OWLClassAxiom> axioms = ontology.getAxioms(concept, Imports.INCLUDED);
						axiomsToRemove.addAll(axioms);
						remover.visit(concept);
	
				        Config.conceptsDisplay.add(concept);
					}
				}
			}		
		}		
		manager.removeAxioms(ontology, axiomsToRemove);
		manager.applyChanges(remover.getChanges());
		axiomsToRemove.clear();

		Set<OWLObjectProperty> roles = getOWLModelManager().getActiveOntology().getObjectPropertiesInSignature();
		for (OWLObjectProperty role : roles) {
			
			Collection<OWLAnnotation> annotations = EntitySearcher.getAnnotations(role, ontology);

			for (OWLAnnotation annotation : annotations) {					
					
				if (annotation.getValue() instanceof OWLLiteral) {
					
					OWLLiteral literal = (OWLLiteral) annotation.getValue();
					String literalString = literal.getLiteral();
				
					if (literalString.contains(tsStringRole)) {				
	
						Set<OWLObjectPropertyAxiom> axioms = ontology.getAxioms(role, Imports.INCLUDED);
						axiomsToRemove.addAll(axioms);
						remover.visit(role);
	
						Config.rolesDisplay.add(role);
					}
				}
			}		
		}
        manager.removeAxioms(ontology, axiomsToRemove);		
		manager.applyChanges(remover.getChanges());
		
		if (Config.displayResults) {
			
			String displayString = "Concepts deleted (total " + Config.conceptsDisplay.size() + "):\n";				
			ArrayList<String> arrayString = new ArrayList<String>();    
			for (OWLClass concept : Config.conceptsDisplay) {
				arrayString.add(concept.getIRI().getShortForm());
			}
		    Collections.sort(arrayString);
		    for (String concept : arrayString) {
		    	displayString = displayString + concept + "\n";
		    }
		
			arrayString = new ArrayList<String>(); 
		    displayString = displayString + "\nRoles deleted (total " + Config.rolesDisplay.size() + "):\n";
			for (OWLObjectProperty role : Config.rolesDisplay) {
				arrayString.add(role.getIRI().getShortForm());
			}
		    Collections.sort(arrayString);
		    for (String role : arrayString) {
		    	displayString = displayString + role + "\n";
		    }

		    JOptionPane.showMessageDialog(getOWLWorkspace(), displayString);
		}
	}
}

/*
for (OWLAxiom axiom : ontology.getAxioms()) {
if (axiom.getSignature().contains(concept)) {
    axiomsToRemove.add(axiom);
}
}	

for (OWLAxiom axiom : ontology.getAxioms()) {
    if (axiom.getSignature().contains(role)) {
        axiomsToRemove.add(axiom);
    }
}	



//System.out.println("concept = " + concept.getIRI().getShortForm());

//System.out.println("annotation = " + annotation.getValue());

//------------------------------------
//Set<OWLLiteral> annotations = new HashSet<>();
//for (OWLAnnotation label : labelAnnotations) {
//		System.out.println("label = " + label.getValue());
//		annotations.add((OWLLiteral) label.getValue());
//-----------------------------------------------------------
//Stream<OWLAnnotation> annotations = getAnnotations(entity, ontology);
//for (OWLAnnotation annotation : annotations) {
//	System.out.println("annotation = " + annotation);
//}


//---------------------------------------------
//
//OWLOntology ontology = getOWLModelManager().getActiveOntology();
//System.out.println("ontology = " + ontology);
//
//Set<OWLClass> concepts = getOWLModelManager().getActiveOntology().getClassesInSignature();
//
//for (OWLClass concept : concepts) {
//	System.out.println("concept = " + concept.getIRI().getShortForm());
//	Set<OWLAnnotation> annotations = concept.getAnnotations(ontology);
//	for (OWLAnnotation annotation : annotations) {
//		System.out.println("annotation = " + annotation);
//	}
//}
//
//-----------------------------------------------

//StringBuilder message = new StringBuilder("Signature_Keep_All 13 ............................");		
//JOptionPane.showMessageDialog(getOWLWorkspace(), message.toString());
//
//Set<OWLClass> classes = getOWLModelManager().getActiveOntology().getClassesInSignature();
//
//for (OWLClass classA : classes) {
//	System.out.println("classA = " + classA.getIRI().getShortForm());
//}
//
//--------------------------------
//
//Set<OWLAnnotation> annotations = classA.getAnnotations(Config.getOntology());
//for (OWLAnnotation annotation : annotations) {
//	
//	OWLLiteral literal = (OWLLiteral) annotation.getValue();
//	String literalString = literal.getLiteral();
//
//	if (literalString.contains("]ts-")) {
//		Set<OWLAxiom> axiomsToRemove = new HashSet<OWLAxiom>();
//		OWLAxiom ax = Config.getFactory().getOWLAnnotationAssertionAxiom(classA.getIRI(), annotation);
//        axiomsToRemove.add(ax);
//        Config.getManager().removeAxioms(Config.getOntology(), axiomsToRemove);
//	}
//}
//String commentAnnoString = " ";
//if (ts.contains("forget")) { 
//	commentAnnoString = "]ts-individual-forget"; 
//}
//else { 
//	commentAnnoString = "]ts-individual-keep"; 
//}
//OWLAnnotation commentAnnotation = Config.getFactory().getOWLAnnotation(Config.getFactory().getRDFSComment(),
//		Config.getFactory().getOWLLiteral(commentAnnoString));
//OWLAxiom ax = Config.getFactory().getOWLAnnotationAssertionAxiom(classA.getIRI(), commentAnnotation);
//Config.getManager().applyChange(new AddAxiom(Config.getOntology(), ax));

*/