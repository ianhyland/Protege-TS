//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import org.protege.editor.owl.ui.action.ProtegeOWLAction;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.EntityType;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

public class Roles_Forget extends ProtegeOWLAction {

	private static final long serialVersionUID = 1L;

	public void initialise() throws Exception { }

	public void dispose() throws Exception {}

	public void actionPerformed(ActionEvent arg0) {
			
		String tsString = Config.tsForget;
		
		if (LicenceExpired.run()) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			return;
		}
		if (Config.firstRun) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			Config.firstRun = false;
		}
		
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		OWLDataFactory factory = getOWLDataFactory();
		OWLOntology ontology = getOWLModelManager().getActiveOntology();
		if (ontology.getClassesInSignature().size() == 0) {
		    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.errorFirstLoadAnOntologyString));
			return;
		}
		
		OWLClass concept = getOWLWorkspace().getOWLSelectionModel().getLastSelectedClass();
		OWLEntity entity = getOWLWorkspace().getOWLSelectionModel().getSelectedEntity();

		if (entity == null) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.errorFirstSelectAConceptString));
			return;			
		}
		if (!(entity.isType(EntityType.CLASS))) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.errorFirstSelectAConceptString));
			return;
		}

		String displayString = "";
		try {
			int roleLoopCount = Integer.parseInt(JOptionPane.showInputDialog(getOWLWorkspace(),
					            "Select the number of role hops (integer 1 to " + String.valueOf(Config.maxRoleLoopCount) + ") to process"));
			if (roleLoopCount >= 1 && roleLoopCount <= Config.maxRoleLoopCount) {
				displayString = Roles.run(ontology, manager, factory, concept, tsString, roleLoopCount);				
			}
			else {
				JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.errorNumberOfHopsString));
				return;
			}

		}
		catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.errorNumberOfHopsString));
			return;
		}
			
		if (Config.displayResults) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(displayString));
		}
	}
}



/*

String name=JOptionPane.showInputDialog(getOWLWorkspace(),"Enter Name");
 
 			Object[] options = {"Hopes 1", "Hopes 2", "Hopes 3", "Hopes 4", "Hopes 5", "Hopes 6", "Hopes 7", "Hopes 8"};
			int roleLoopCount = JOptionPane.showOptionDialog(getOWLWorkspace(), "Select the number of role hopes to process", "",
							    JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[2]);
							    
-----------------------------------
					for (OWLClassExpression classExpressionNested : classExpression.getNestedClassExpressions()) {

						if (classExpressionNested instanceof OWLObjectSomeValuesFrom && classExpressionNested.getNestedClassExpressions().size() == 2) {

							OWLClassExpression fillerExpression = (((OWLObjectSomeValuesFrom)classExpressionNested).getFiller());
							OWLClass filler = (OWLClass)fillerExpression;
							new Term_Selection_Concept_Update (ontology, manager, factory, filler, "]term-selection-concept-keep");
							fillersCount++;
							fillers.add(filler);
							
							OWLObjectPropertyExpression propertyExpression = ((OWLObjectSomeValuesFrom)classExpressionNested).getProperty();
							OWLObjectProperty property = (OWLObjectProperty)propertyExpression;
							//roles        new Term_Selection_Concept_Update (ontology, manager, factory, filler, "]term-selection-concept-keep");
							properties.add(property);
						}
						else if(classExpressionNested instanceof OWLClass) {
							OWLClass concept1 = (OWLClass)classExpressionNested;
							new Term_Selection_Concept_Update (ontology, manager, factory, concept1, "]term-selection-concept-keep");
							conceptsCount++;
							concepts.add(concept1);
						}
						else System.out.println("Error: Equivalent, unknown type\n");
---------------------------------
						if (classExpressionNested instanceof OWLObjectAllValuesFrom) System.out.println("OWLObjectAllValuesFrom");
						else if(classExpressionNested instanceof OWLObjectIntersectionOf) System.out.println("OWLObjectIntersectionOf");
						else if(classExpressionNested instanceof OWLObjectUnionOf) System.out.println("OWLObjectUnionOf");
--------------------------------
OWLObjectSomeValuesFrom object) {
    OWLClassExpression filler=object.getFiller();
----------------------------
        OWLObjectPropertyExpression sub = a.getSubProperty();
        OWLObjectPropertyExpression sup = a.getSuperProperty();
-------------------------------
vote down vote up
UnfoldingVisitor(Set<OWLClass> unfoldClasses, OWLOntology ontology) throws NonDeterministicUnfoldException {
	this.unfoldClasses = new HashMap<OWLClass, OWLClassExpression>();
	factory = ontology.getOWLOntologyManager().getOWLDataFactory();
	
	for(OWLClass owlClass : unfoldClasses) {
		Set<OWLEquivalentClassesAxiom> eqAxioms = ontology.getEquivalentClassesAxioms(owlClass);
		if (eqAxioms != null && !eqAxioms.isEmpty()) {
			if(eqAxioms.size() > 1) {
				throw new NonDeterministicUnfoldException("Non deterministic unfold for class: "+owlClass.getIRI());
			}
			OWLEquivalentClassesAxiom eqAxiom = eqAxioms.iterator().next();
			Set<OWLClassExpression> expressions = eqAxiom.getClassExpressionsMinus(owlClass);
			if (expressions.size() == 1) {
				this.unfoldClasses.put(owlClass, expressions.iterator().next());
			}
			else if (expressions.size() > 1) {
				OWLClassExpression ce = factory.getOWLObjectIntersectionOf(expressions);
				this.unfoldClasses.put(owlClass, ce);
			}
		}
	}
	
	// TODO check that there are no cycles in the unfold expressions, otherwise this unfold will not terminate!
---------------------------------
		else if (ax instanceof OWLEquivalentClassesAxiom) {
			for (OWLClassExpression x : ((OWLEquivalentClassesAxiom)ax).getClassExpressions()) {
				xs.addAll(getClassExpressionReferencedBy(p,x));
			}
		}
--------------------------------------------
public Collection<OWLClass> getChildren(OWLClass parent) {
    Collection<OWLClass> result = new HashSet<OWLClass>();
    for (OWLOntology ont : getRootOntology().getImportsClosure()) {
        for (OWLAxiom ax : ont.getReferencingAxioms(parent)) {
            if (ax instanceof OWLSubClassOfAxiom) {
                OWLSubClassOfAxiom sca = (OWLSubClassOfAxiom) ax;
                if (!sca.getSubClass().isAnonymous()) {
                    Set<OWLClassExpression> conjuncts = sca.getSuperClass().asConjunctSet();
                    if (conjuncts.contains(parent)) {
                        result.add(sca.getSubClass().asOWLClass());
                    }
                }
            }
            else if (ax instanceof OWLEquivalentClassesAxiom) {
                OWLEquivalentClassesAxiom eca = (OWLEquivalentClassesAxiom) ax;
                for (OWLClassExpression ce : eca.getClassExpressions()) {
                    if (ce.containsConjunct(parent)) {
                        for (OWLClassExpression sub : eca.getClassExpressions()) {
                            if (!sub.isAnonymous() && !sub.equals(ce)) {
                                result.add(sub.asOWLClass());
                            }
                        }
                    }
                }
            }
        }
    }
    return result;
}----------------------------------------------
  public static boolean containsDoubleObjectSomeRestriction(OWLClassExpression d) {
    Set<OWLObjectPropertyExpression> roles = new HashSet<>();
    for(OWLClassExpression c : d.getNestedClassExpressions()) {
      if(c instanceof OWLObjectSomeValuesFrom) {
        OWLObjectPropertyExpression role = ((OWLObjectSomeValuesFrom)c).getProperty();                                
        boolean roleExists = !roles.add(role);
        if(roleExists)
          return true;
      }
    }
    return false;
------------------------------------------
PrefixManager pm= new DefaultPrefixManager("http://www.co-ode.org/ontologies/pizza/pizza.owl#");
OWLClass american=factory.getOWLClass("American", pm);
Set<OWLClassAxiom> tempAx=localOntology.getAxioms(american);
for(OWLClassAxiom ax: tempAx){
for(OWLClassExpression nce:ax.getNestedClassExpressions())
if(nce.getClassExpressionType()!=ClassExpressionType.OWL_CLASS)
System.out.println(ax);
}---------------------------------------------------
//					  OWLClassExpression expression = classExpression.getNestedClassExpressions());
//
//					  if(expression instanceof OWLObjectAllValuesFrom) {
//				    }
//				  }
//				  
//			for (OWLClassExpression operand : classExpressions.getOperands()) {
//				
//			}
//			
//			OWLObjectIntersectionOf ce) {
//			    for (OWLClassExpression operand : ce.getOperands()) {
//			        operand.accept(this);
//			    }
//			}
//			OWLObjectSomeValuesFrom ce) {
//			    Set<OWLClassExpression> fillers = restrictions.get(ce.getProperty());
//			    if (fillers == null) {
//			        fillers = new HashSet<>();
//			        restrictions.put(ce.getProperty(), fillers);
//			    }
//			    fillers.add(ce.getFiller());
			
//			for (OWLClassExpression classExpression : classExpressions) {
//				System.out.println("classExpression = " + classExpression + "\n");
//				classExpressionsNext = (Set<OWLClassExpression>)classExpression;
//			}

		
//		System.out.println("classExpressionsNext = " + classExpressionsNext + "\n");
//		
//		for (OWLClassExpression classExpression : classExpressionsNext) {
//			System.out.println("classExpression = " + classExpression + "\n");
//		
//		}
				
//		for (OWLEquivalentClassesAxiom equivalentClassesAxiom : equivalentClassesAxiomsNext) {
//			System.out.println("equivalentClassesAxiom 11 = " + equivalentClassesAxiom + "\n");
//			
//			Set<OWLClassExpression> classExpressions = equivalentClassesAxiom.getClassExpressions();
//			for (OWLClassExpression classExpression : classExpressions) {
//				System.out.println("classExpression 11 = " + classExpression + "\n");
////				Set<OWLEquivalentClassesAxiom> equivalentClassesAxiomsNext = (Set<OWLEquivalentClassesAxiom>)classExpression;
//			}
//		}
		
//			equivalentClassesAxiomsNext = (Set<OWLEquivalentClassesAxiom>)classExpression;
		
//		classExpressions = equivalentClassesAxiom.getClassExpressions();
//		equivalentClassesAxioms = ontology.getEquivalentClassesAxioms((OWLClass) classExpression);
			
		
//		Set<OWLClassExpression> classExpressions = null;
//		while (true) {
//			
//			System.out.println("\n");
//			if (firstPass) equivalentClassesAxioms = ontology.getEquivalentClassesAxioms(concept);
//	
//			for (OWLEquivalentClassesAxiom equivalentClassesAxiom : equivalentClassesAxioms) {
//				System.out.println("equivalentClassesAxiom = " + equivalentClassesAxiom + "\n");
//				
//				classExpressions = equivalentClassesAxiom.getClassExpressions();
//				for (OWLClassExpression classExpression : classExpressions) {
//					System.out.println("classExpression = " + classExpression + "\n");
//				}
//			}
//			
//			classExpressions = equivalentClassesAxiom.getClassExpressions();
//			equivalentClassesAxioms = ontology.getEquivalentClassesAxioms((OWLClass) classExpression);
//		}
			
			
//			Set<OWLEquivalentClassesAxiom> equivalentClassesAxioms1 = (Set<OWLEquivalentClassesAxiom>)classExpression;
			
			
//			Set<OWLClass> ecaNamedClasses = eca.getNamedClasses();
//			System.out.println("ecaNamedClasses = " + ecaNamedClasses + "\n");
//		
//			for (OWLClassExpression ce : eca.getClassExpressions()) {
//
//				Set<OWLClassExpression> ce1 = eca.getClassExpressionsMinus(concept);
//				System.out.println("ce1 = " + ce1 + "\n");
//			}
//		}
 
		
//public static OWLClassExpression  getEquivalentClassDefinition(OWLEquivalentClassesAxiom equ) {
//		
//	Iterator<OWLClassExpression> expIter = (equ).getClassExpressions().iterator();
//	expIter.next();
//	return expIter.next();
//}
		
		
//                    Set<OWLClass> qq = eca.getNamedClasses();
		
	
//        for (OWLEquivalentClassesAxiom eca2 : ontology.getEquivalentClassesAxioms(concept)) {
//            for (OWLClassExpression ce : eca2.getClassExpressions()) {
//                if (ce instanceof OWLObjectUnionOf) {
//                    for (OWLObject child : ((OWLObjectUnionOf)ce).getOperands()) {
//                        //we reverse only named classes
//                        if (child instanceof OWLClass) {
//                            this.getOwlGraphWrapper().getManager().addAxiom(ont, 
//                                    ont.getOWLOntologyManager().getOWLDataFactory().
//                                        getOWLSubClassOfAxiom((OWLClass) child, cls));
//                        }
//                    }
//                }
//            }
//
//            private static String equivAxiomToString(OWLEquivalentClassesAxiom axiom) {
//            	  StringBuilder equivalentClassesString = new StringBuilder("Equivalence: ");
//            	  Iterator<OWLClass> classIterator = axiom.getNamedClasses().iterator();
//            	  while (classIterator.hasNext()) {
//            	   equivalentClassesString.append(classIterator.next().toString());
//            	   if (classIterator.hasNext()) {
//            	    equivalentClassesString.append(" == ");
//            	   }
//            	  }
//            	  return equivalentClassesString.toString();
//            	 }
//            	}
//
//        private void processOWLEquivalentClassesAxioms()
//        {
//         Set<OWLEquivalentClassesAxiom> axioms = ontology.getOWLEquivalentClassesAxioms(concepts);
//         for (OWLEquivalentClassesAxiom axiom : axioms) {
//          axiom.getNamedClasses().forEach(this::generateOWLClassDeclarationAxiom);
//         }
//         this.assertedOWLAxioms.addAll(axioms);
//        }

------------------------------------------------
public Set<OWLClass> materializeClassExpressionsReferencedBy(OWLObjectProperty p) {
		Set<OWLClassExpression> xs = new HashSet<OWLClassExpression>();
		for (OWLAxiom ax : outputOntology.getReferencingAxioms(p, Imports.INCLUDED)) {
			if (ax instanceof OWLSubClassOfAxiom) {
				xs.addAll(getClassExpressionReferencedBy(p, ((OWLSubClassOfAxiom)ax).getSuperClass()));
			}
			else if (ax instanceof OWLClassAssertionAxiom) {
				xs.addAll(getClassExpressionReferencedBy(p, ((OWLClassAssertionAxiom)ax).getClassExpression()));
			}
			else if (ax instanceof OWLEquivalentClassesAxiom) {
				for (OWLClassExpression x : ((OWLEquivalentClassesAxiom)ax).getClassExpressions()) {
					xs.addAll(getClassExpressionReferencedBy(p,x));
				}
			}
		}
		return materializeClassExpressions(xs);
	}

	
	 * E.g. if x = A and B and q some (p some z), return z 
	 * 
	 * @param p
	 * @param x
	 * @return all expressions that follow a 'p' in a SOME restriction
	
	private Set<OWLClassExpression> getClassExpressionReferencedBy(OWLObjectProperty p, OWLClassExpression x) {
		Set<OWLClassExpression> xs = new HashSet<OWLClassExpression>();
		if (x instanceof OWLObjectSomeValuesFrom) {
			OWLObjectSomeValuesFrom svf = (OWLObjectSomeValuesFrom)x;
			if (svf.getProperty().equals(p)) {
				return Collections.singleton(svf.getFiller());
			}
			else {
				return getClassExpressionReferencedBy(p, svf.getFiller());
			}
		}
		else if (x instanceof OWLObjectIntersectionOf) {
			for (OWLClassExpression op : ((OWLObjectIntersectionOf)x).getOperands()) {
				xs.addAll(getClassExpressionReferencedBy(p,op));
			}
		}
		else if (x instanceof OWLObjectUnionOf) {
			for (OWLClassExpression op : ((OWLObjectUnionOf)x).getOperands()) {
				xs.addAll(getClassExpressionReferencedBy(p,op));
			}
		}

		return xs;
	}

	public OWLClass materializeClassExpression(OWLClassExpression ce) {
		if (materializedClassExpressionMap.containsKey(ce))
			return materializedClassExpressionMap.get(ce);
		else
			return materializeClassExpressions(Collections.singleton(ce)).iterator().next();
	}
	
	 * Note: does not flush
	 * @param ces
	 * @return classes
	 
	public Set<OWLClass> materializeClassExpressions(Set<OWLClassExpression> ces) {
		LOG.info("Materializing class expressions: "+ces.size());
		OWLAnnotationProperty rdfsLabel = getOWLDataFactory().getRDFSLabel();
		Set<OWLAxiom> newAxioms = new HashSet<OWLAxiom>();
		Set<OWLClass> newClasses = new HashSet<OWLClass>();
		for (OWLClassExpression ce : ces) {
			if (ce instanceof OWLClass) {
				newClasses.add((OWLClass) ce);
				continue;
			}
			if (materializedClassExpressionMap.containsKey(ce)) {
				newClasses.add(materializedClassExpressionMap.get(ce));
				continue;
			}

			OWLClass mc = getOWLDataFactory().getOWLClass(IRI.create("http://x.org#"+MD5(ce.toString())));
			newAxioms.add(getOWLDataFactory().getOWLDeclarationAxiom(mc));
			newAxioms.add(getOWLDataFactory().getOWLEquivalentClassesAxiom(mc, ce));
			newAxioms.add(
					getOWLDataFactory().getOWLAnnotationAssertionAxiom(rdfsLabel, mc.getIRI(), 
							getOWLDataFactory().getOWLLiteral(generateLabel(ce)))
			);
			LOG.info(mc + " EQUIV_TO "+ce);
			materializedClassExpressionMap.put(ce, mc);
			newClasses.add(mc);
		}
		// some CEs will be identical, but they will be mapped to the same class.
		// we might be able to optimize by pre-filtering dupes
		addAxiomsToOutput(newAxioms, false);
		LOG.info("Materialized "+ces.size()+ " class expressions, axioms: "+newAxioms.size()+", new classes:"+newClasses.size());


		return newClasses;
	}

	public String MD5(String md5) {
		try {
			java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
			byte[] array = md.digest(md5.getBytes());
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < array.length; ++i) {
				sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1,3));
			}
			return sb.toString();
		} catch (java.security.NoSuchAlgorithmException e) {
		}
		return null;
	}
-------------------------------------------------
	    NodeSet<OWLClass> superConceptsNodeSet = reasoner.getSuperClasses(concept, false);
        Set<OWLClass> superConcepts = superConceptsNodeSet.getFlattened();
        for(OWLClass superConcept : superConcepts) {
        	System.out.println("superConcept = " + superConcept + "\n");       
        }
-----------------------------------------------

	private OWLClass expressionToClass(OWLClassExpression x) {
		
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		OWLDataFactory factory = getOWLDataFactory();
		OWLOntology ontology = getOWLModelManager().getActiveOntology();
		
		Map<OWLClassExpression, OWLClass> expressionToClassMap;
		expressionToClassMap = new HashMap<OWLClassExpression, OWLClass>();
		int idNum = 1;
		
		if (x instanceof OWLClass) return (OWLClass)x;
		
		if (this.expressionToClassMap.containsKey(x)) return this.expressionToClassMap.get(x);
		
		OWLClass c = factory.getOWLClass(IRI.create("http://owlsim.org#"+idNum));
		idNum++;

		OWLEquivalentClassesAxiom eca = factory.getOWLEquivalentClassesAxiom(c, x);
		manager.addAxiom(ontology, eca);
		expressionToClassMap.put(x, c);

		// fully fold tbox (AND and SOME only)
		if (x instanceof OWLObjectIntersectionOf) {
			for (OWLClassExpression y : ((OWLObjectIntersectionOf)x).getOperands()) {
				expressionToClass(y);
			}
		}
		else if (x instanceof OWLObjectSomeValuesFrom) {
			expressionToClass(((OWLObjectSomeValuesFrom)x).getFiller());
		}
		return c;
	}
--------------------------------------------------------
protected static Set<OWLClass> getAllSubClasses(OWLClass cls, OWLReasoner r, boolean reflexive, String idSpace, CurieHandler curieHandler) {
    Set<OWLClass> allSubClasses = r.getSubClasses(cls, false).getFlattened();
    Iterator<OWLClass> it = allSubClasses.iterator();
    while (it.hasNext()) {
        OWLClass current = it.next();
        if (current.isBuiltIn()) {
            it.remove();
            continue;
        }
        String id = curieHandler.getCuri(current);
        if (id.startsWith(idSpace) == false) {
            it.remove();
            continue;
        }
    }
    if (reflexive) {
        allSubClasses.add(cls);
    }
    return allSubClasses;
}
-----------------------------------
		OWLReasoner reasoner = getOWLModelManager().getReasoner();
        Node<OWLClass> equivalentClasses = reasoner.getEquivalentClasses(concept);
        
//        Set<OWLClass> result = null;
//        if (concept.isAnonymous()) {
//            result = equivalentClasses.getEntities();
//        } else {
//            result = equivalentClasses.getEntitiesMinus(concept.asOWLClass());
//        }

---------------------------------------
//		>> >    OWLClass owlClass = getClass(ontology, className);
//		>> >    Set<OWLClassAxiom> classAxioms = ontology.getAxioms(owlClass);
//		>> >    Set<String> classAxiomStrings = new HashSet<String>();
		
		Set<OWLClassExpression> classExpressions = concept.getEquivalentClasses(ontology);
		>> >    Iterator<OWLClassExpression> classExpressionsIt =
		>> >
		classExpressions.iterator();
		>> >    while (classExpressionsIt.hasNext()) {
		>> >         OWLClassExpression classExpression =
		>> >                          (OWLClassExpression)
		classExpressionsIt.next();
		>> >         classStringSet.add(classExpression.toString());
		>> >    }
		>> >    return classStringSet;
		
		
//		System.out.println(concept.getEquivalentClasses(ontology));
		
//		OWLClass cls = factory.getOWLClass(IRI.create(className));
//		Set<OWLClassExpression> equivClsExprs = concept.getEquivalentClasses(ontology);
		
//		Set<OWLClass> equivalentConcepts = concept.getEquivalentClasses(ontology);
-----------------------------------------------
 public static Set<OWLClass> getEquivalentClasses(OWLClassExpression cls) {

        Node<OWLClass> equivalentClasses = reasoner.getEquivalentClasses(cls);
        Set<OWLClass> result = null;
        if (cls.isAnonymous()) {
            result = equivalentClasses.getEntities();
        } else {
            result = equivalentClasses.getEntitiesMinus(cls.asOWLClass());
        }
        return result;
        }
-----------------------------------------------------
OWLOntology ontology;
    try (InputStream in = new ByteArrayInputStream(s.getBytes(StandardCharsets.UTF_8))) {
        ontology = OntManagers.createONT().loadOntologyFromOntologyDocument(in);
    }
    System.out.println("========");
    OWLEquivalentClassesAxiom equivalentClassesAxiom = ontology.axioms(AxiomType.EQUIVALENT_CLASSES).findFirst().orElseThrow(IllegalArgumentException::new);
    OWLObjectIntersectionOf anon = equivalentClassesAxiom.classExpressions()
            .filter(e -> ClassExpressionType.OBJECT_INTERSECTION_OF.equals(e.getClassExpressionType()))
            .map(OWLObjectIntersectionOf.class::cast)
            .findFirst().orElseThrow(IllegalArgumentException::new);
    System.out.println(anon.getOperandsAsList().get(0)); // <-- always person
    System.out.println(anon.getOperandsAsList().get(1)); // <-- always anon ObjectSomeValuesFrom
    System.out.println(OWLObjectSomeValuesFrom.class.cast(anon.getOperandsAsList().get(1)).getFiller()); // <--always dog

-----------------------------------------------------------------
 Set<OWLObjectProperty> roles = Config.getOntology().getObjectPropertiesInSignature();
 
 Set<OWLClass> classes = Config.getOntology().getClassesInSignature();
 Set<OWLClassExpression> equivalentClasses = classA.getEquivalentClasses(Config.getOntology());	        	
 for (OWLClassExpression equivalentClass : equivalentClasses) {

if (equivalentClass.getClassExpressionType() == ClassExpressionType.OWL_CLASS) {
			            	
String equivalentClassString = ((HasIRI) equivalentClass).getIRI().getShortForm().toString();
				        	
				        	
		System.out.println("concept 11 = " + concept);
		
------------------------------
		<Set>OWLClass concepts = getOWLWorkspace().getOWLSelectionModel().getLastSelectedClasses();
		
		OWLSelectionModel selectionModel = getOWLWorkspace().getOWLSelectionModel();
		System.out.println("selectionModel = " + selectionModel);
		
		 OWLClass lastSelectedClass = selectionModel.getLastSelectedClass(); 
		 System.out.println("lastSelectedClass = " + lastSelectedClass);
			
		if (getOWLWorkspace().getOWLSelectionModel().getSelectedObject() instanceof OWLClass) 
		System.out.println(getOWLWorkspace().getOWLSelectionModel().getSelectedObject());
		 
------------------------------
String text = getEntityName();
OWLOntology activeOntology = owlEditorKit.getModelManager().getActiveOntology();
OWLOntologyManager manager = owlEditorKit.getModelManager().getOWLOntologyManager();
OWLOntologyFormat format = manager.getOntologyFormat(activeOntology);
------------------------------

//Set selected values in given list
public void setSelectedValues(Set<OWLRelation> owlRelations, boolean shouldScroll) {
    getSelectionModel().clearSelection();
    if (getSelectionMode() == ListSelectionModel.MULTIPLE_INTERVAL_SELECTION){
        int firstIndex = -1;
        for (int i=0; i<getModel().getSize(); i++){
            if (owlRelations.contains(getModel().getElementAt(i))){
                getSelectionModel().addSelectionInterval(i, i);
                if (firstIndex == -1){
                    firstIndex = i;
                }
            }
        }
        if (shouldScroll && firstIndex != -1){
            scrollRectToVisible(new Rectangle(getCellBounds(firstIndex, firstIndex)));
        }
    }
}

//Get selected objects in given list
@SuppressWarnings("unchecked")
public java.util.List<OWLRelation> getSelectedOWLObjects(){
    List<OWLRelation> sel = new ArrayList<OWLRelation>();
    for (Object o : getSelectedValues()){
        sel.add((OWLRelation) o);
    }
    return sel;
}
}

-------------------------------
if (getOWLWorkspace().getOWLSelectionModel().getSelectedObject() instanceof OWLClass){
    refill();
----------------------------
OWLClass selectedClass = getOWLWorkspace().getOWLSelectionModel().getLastSelectedClass();
setEnabled(selectedClass != null &&
      getOWLModelManager().getOWLHierarchyManager().getOWLClassHierarchyProvider().getChildren(selectedClass).size() > 1);
---------------------------------------
OWLClass cls = getOWLWorkspace().getOWLSelectionModel().getLastSelectedClass();
// TODO: Push into OWLAPI
Set<OWLClass> subClses = getOWLModelManager().getOWLHierarchyManager().getOWLClassHierarchyProvider().getChildren(cls);
OWLClassExpression coveringDesc = getOWLDataFactory().getOWLObjectUnionOf(subClses);
OWLSubClassOfAxiom ax = getOWLDataFactory().getOWLSubClassOfAxiom(cls, coveringDesc);
getOWLModelManager().applyChange(new AddAxiom(getOWLModelManager().getActiveOntology(), ax));

------------------------------------
Set<OWLLiteral> annotations = new HashSet<>();
for (OWLAnnotation label : labelAnnotations) {
		System.out.println("label = " + label.getValue());
		annotations.add((OWLLiteral) label.getValue());
-----------------------------------------------------------
Stream<OWLAnnotation> annotations = getAnnotations(entity, ontology);
for (OWLAnnotation annotation : annotations) {
	System.out.println("annotation = " + annotation);
?//}


---------------------------------------------

OWLOntology ontology = getOWLModelManager().getActiveOntology();
System.out.println("ontology = " + ontology);

Set<OWLClass> concepts = getOWLModelManager().getActiveOntology().getClassesInSignature();

for (OWLClass concept : concepts) {
	System.out.println("concept = " + concept.getIRI().getShortForm());
	Set<OWLAnnotation> annotations = concept.getAnnotations(ontology);
	for (OWLAnnotation annotation : annotations) {
		System.out.println("annotation = " + annotation);
	}
}

-----------------------------------------------

StringBuilder message = new StringBuilder("Signature_Keep_All 13 ............................");		
JOptionPane.showMessageDialog(getOWLWorkspace(), message.toString());

Set<OWLClass> classes = getOWLModelManager().getActiveOntology().getClassesInSignature();

for (OWLClass classA : classes) {
	System.out.println("classA = " + classA.getIRI().getShortForm());
}

--------------------------------

Set<OWLAnnotation> annotations = classA.getAnnotations(Config.getOntology());
for (OWLAnnotation annotation : annotations) {
	
	OWLLiteral literal = (OWLLiteral) annotation.getValue();
	String literalString = literal.getLiteral();

	if (literalString.contains("]ts-")) {
		Set<OWLAxiom> axiomsToRemove = new HashSet<OWLAxiom>();
		OWLAxiom ax = Config.getFactory().getOWLAnnotationAssertionAxiom(classA.getIRI(), annotation);
        axiomsToRemove.add(ax);
        Config.getManager().removeAxioms(Config.getOntology(), axiomsToRemove);
	}
}
String commentAnnoString = " ";
if (ts.contains("forget")) { 
	commentAnnoString = "]ts-individual-forget"; 
}
else { 
	commentAnnoString = "]ts-individual-keep"; 
}
OWLAnnotation commentAnnotation = Config.getFactory().getOWLAnnotation(Config.getFactory().getRDFSComment(),
		Config.getFactory().getOWLLiteral(commentAnnoString));
OWLAxiom ax = Config.getFactory().getOWLAnnotationAssertionAxiom(classA.getIRI(), commentAnnotation);
Config.getManager().applyChange(new AddAxiom(Config.getOntology(), ax));


*/