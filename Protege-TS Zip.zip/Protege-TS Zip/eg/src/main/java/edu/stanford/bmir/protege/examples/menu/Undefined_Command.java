//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.util.Collection;
import java.util.Set;

import org.semanticweb.owlapi.model.AddAxiom;
import org.semanticweb.owlapi.model.OWLAnnotation;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.search.EntitySearcher;

public class Undefined_Command {
	
	public Undefined_Command () { }
			
	public static String run (OWLOntology ontology, OWLOntologyManager manager, OWLDataFactory factory,
							  Set<OWLClass> concepts, Set<OWLObjectProperty> roles, String tsString) {	
					
		for (OWLClass concept : concepts) {
			
			Boolean tsStringFound = false;
			Collection<OWLAnnotation> annotations = EntitySearcher.getAnnotations(concept, ontology);

			for (OWLAnnotation annotation : annotations) {				
				
				if (annotation.getValue() instanceof OWLLiteral) {
					
					OWLLiteral literal = (OWLLiteral) annotation.getValue();
					String literalString = literal.getLiteral();
				
					if (literalString.contains(Config.tsConcept)) {
						tsStringFound = true;
					}
				}
			}

			if (!tsStringFound) {
				OWLAnnotation commentAnnotation = factory.getOWLAnnotation(factory.getRDFSComment(),factory.getOWLLiteral(Config.tsConcept + tsString));
				OWLAxiom ax = factory.getOWLAnnotationAssertionAxiom(concept.getIRI(), commentAnnotation);
				manager.applyChange(new AddAxiom(ontology, ax));
				Config.conceptsDisplay.add(concept);
			}
		}
		
		for (OWLObjectProperty role : roles) {
			
			Boolean tsStringFound = false;
			Collection<OWLAnnotation> annotations = EntitySearcher.getAnnotations(role, ontology);

			for (OWLAnnotation annotation : annotations) {
				
				if (annotation.getValue() instanceof OWLLiteral) {
					
					OWLLiteral literal = (OWLLiteral) annotation.getValue();
					String literalString = literal.getLiteral();
				
					if (literalString.contains(Config.tsRole)) {
						tsStringFound = true;
					}
				}
			}

			if (!tsStringFound) {
				OWLAnnotation commentAnnotation = factory.getOWLAnnotation(factory.getRDFSComment(),factory.getOWLLiteral(Config.tsRole + tsString));
				OWLAxiom ax = factory.getOWLAnnotationAssertionAxiom(role.getIRI(), commentAnnotation);
				manager.applyChange(new AddAxiom(ontology, ax));
				Config.rolesDisplay.add(role);
			}
		}
					
	    return DisplayString.run(tsString);
	}	
}
