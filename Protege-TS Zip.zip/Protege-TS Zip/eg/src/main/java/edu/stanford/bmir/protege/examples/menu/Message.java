//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.awt.Font;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Message {
	
	public Message () { }
	
	public static JScrollPane block (String message) {

		Font font = new Font("Courier New", Font.PLAIN, 25);
		
		String[] array = message.split("\n");
		
		int maxWidth = 0;
		for (String string : array) {
			int tmp = string.length();
			if (tmp > maxWidth) maxWidth = tmp;
		}
		
		int maxLines = 40;
		if (array.length+1 < maxLines) maxLines = array.length+1;
		
		JTextArea textArea = new JTextArea(maxLines, maxWidth);
	    textArea.setFont(font);
	    textArea.setText(message);
	    textArea.setEditable(false);
	    JScrollPane scrollPane = new JScrollPane(textArea);
	    
	    return scrollPane;
	}
}

//public static JScrollPane line (String message) {
//
//	JTextArea textArea = new JTextArea(1, message.length());
//    textArea.setFont(font);
//    textArea.setText(message);
//    textArea.setEditable(false);
//    JScrollPane scrollPane = new JScrollPane(textArea);
//    
//    return scrollPane;
//}	