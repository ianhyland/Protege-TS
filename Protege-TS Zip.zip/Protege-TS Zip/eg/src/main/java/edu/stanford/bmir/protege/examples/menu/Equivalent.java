//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.util.Set;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

public class Equivalent {
	
	public Equivalent () { }
			
	public static String run (OWLOntology ontology, OWLOntologyManager manager, OWLDataFactory factory, OWLClass concept, OWLObjectProperty role, String tsString) {	
		
		OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
		OWLReasoner reasoner = reasonerFactory.createReasoner(ontology);
		
		Config.conceptsDisplay.clear();
		Config.rolesDisplay.clear();
				
		if (!(concept == null)) {
			String conceptString = concept.toString().substring(1, concept.toString().length() - 1);
			Config.commandLog.add ("Equivalent Concept " + tsString + " " + conceptString);
			Term_Selection_Concept_Update.run (ontology, manager, factory, concept, tsString);								//add selected concept
		
		    Node<OWLClass> equivalentConceptNode = reasoner.getEquivalentClasses(concept);
		    Set<OWLClass> equivalentConcepts = equivalentConceptNode.getEntitiesMinus(concept);
		    
			for (OWLClass equivalentConcept : equivalentConcepts) {															//add equivalent concepts
				Term_Selection_Concept_Update.run (ontology, manager, factory, equivalentConcept, tsString);
			}
		}
		
		if (!(role == null)) {
			String roleString = role.toString().substring(1, role.toString().length() - 1);
			Config.commandLog.add ("Equivalent Role " + tsString + " " + roleString);
			Term_Selection_Role_Update.run (ontology, manager, factory, role, tsString);									//add selected role
			
			OWLObjectPropertyExpression rolePropertyExpression = (OWLObjectPropertyExpression)role;							//add equivalent roles
			Node<OWLObjectPropertyExpression> rolePropertyExpressionNode = reasoner.getEquivalentObjectProperties(rolePropertyExpression);
			
			for (OWLObjectPropertyExpression rolePropertyExpression1 : rolePropertyExpressionNode) {
				OWLObjectProperty role2 = (OWLObjectProperty)rolePropertyExpression1;
				Term_Selection_Role_Update.run (ontology, manager, factory, role2, tsString);
			}
		}
		
	    return DisplayString.run(tsString);
	}
}

/*


System.out.println("\n rolePropertyExpressionNode = " + rolePropertyExpressionNode);

			Set<OWLEquivalentClassesAxiom> equivalentClassesAxioms = ontology.getEquivalentClassesAxioms(concept);			//add equivalent axioms
			for (OWLEquivalentClassesAxiom equivalentClassesAxiom : equivalentClassesAxioms) {
				
				Set<OWLClassExpression> classExpressions = equivalentClassesAxiom.getClassExpressions();
				for (OWLClassExpression classExpression : classExpressions) {
				
					  Set<OWLClass> concepts = classExpression.getClassesInSignature();										//...concepts
					  for (OWLClass concept1 : concepts) {
						  Term_Selection_Concept_Update.run (ontology, manager, factory, concept1, tsString);
						  Config.addConceptsDisplay(concept1);		
					  }
					  Set<OWLObjectProperty> roles = classExpression.getObjectPropertiesInSignature();						//...roles
					  for (OWLObjectProperty role1 : roles) {
						  if (!role1.asOWLObjectProperty().getIRI().getShortForm().contentEquals("topObjectProperty")) {
							  Term_Selection_Role_Update.run (ontology, manager, factory, role1, tsString);
							  Config.addRolesDisplay(role1);
						  }
					  }
				}
			}


*/
