//This is the Term Selection plugin enhancement to Protege. Copyright (C) 2019 Ian Hyland.
//
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
//License as published by the Free Software Foundation, either version 3 of the License, or any later version.
//
//"This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License along with this program.  If not, see 
//<https://www.gnu.org/licenses/>.
//
//Please contact  ianhyland@ngensys.com  on or before 31 December 2020 with any support queries.

package edu.stanford.bmir.protege.examples.menu;

import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import org.protege.editor.owl.ui.action.ProtegeOWLAction;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.EntityType;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

public class Entity_Keep extends ProtegeOWLAction {

	private static final long serialVersionUID = 1L;

	public void initialise() throws Exception { }

	public void dispose() throws Exception { }

	public void actionPerformed(ActionEvent arg0) {
		
		String tsString = Config.tsKeep;
		
		if (LicenceExpired.run()) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			return;
		}
		if (Config.firstRun) {
			JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.firstRunMessage));
			Config.firstRun = false;
		}

		Config.conceptsDisplay.clear();
		Config.rolesDisplay.clear();		
		
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		OWLDataFactory factory = getOWLDataFactory();
		OWLOntology ontology = getOWLModelManager().getActiveOntology();
		
		if (ontology.getClassesInSignature().size() == 0) {
		    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.errorFirstLoadAnOntologyString));
			return;
		}

		OWLClass concept = getOWLWorkspace().getOWLSelectionModel().getLastSelectedClass();
		OWLObjectProperty role = getOWLWorkspace().getOWLSelectionModel().getLastSelectedObjectProperty();
		OWLEntity entity = getOWLWorkspace().getOWLSelectionModel().getSelectedEntity();

		if (concept == null && role == null) {
		    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(Config.errorFirstSelectAConceptOrRoleString));
			return;
		}
		
		if (entity.isType(EntityType.CLASS)) {
			String conceptString = concept.toString().substring(1, concept.toString().length() - 1);
			Config.commandLog.add ("Entity Concept " + tsString + " " + conceptString);
			Term_Selection_Concept_Update.run (ontology, manager, factory, concept, tsString);
		}			
		
		if (entity.isType(EntityType.OBJECT_PROPERTY)) {
			String roleString = role.toString().substring(1, role.toString().length() - 1);
			Config.commandLog.add ("Entity Role " + tsString + " " + roleString);
			Term_Selection_Role_Update.run (ontology, manager, factory, role, tsString);
		}

		String displayString = DisplayString.run(tsString);
		
		if (Config.displayResults) {
		    JOptionPane.showMessageDialog(getOWLWorkspace(), Message.block(displayString));  
		}
	}
}
/*


concept  = owl:Thing
role = owl:topObjectProperty










		System.out.println("concept 11 = " + concept);
		
------------------------------
		<Set>OWLClass concepts = getOWLWorkspace().getOWLSelectionModel().getLastSelectedClasses();
		
		OWLSelectionModel selectionModel = getOWLWorkspace().getOWLSelectionModel();
		System.out.println("selectionModel = " + selectionModel);
		
		 OWLClass lastSelectedClass = selectionModel.getLastSelectedClass(); 
		 System.out.println("lastSelectedClass = " + lastSelectedClass);
			
		if (getOWLWorkspace().getOWLSelectionModel().getSelectedObject() instanceof OWLClass) 
		System.out.println(getOWLWorkspace().getOWLSelectionModel().getSelectedObject());
		 
------------------------------
String text = getEntityName();
OWLOntology activeOntology = owlEditorKit.getModelManager().getActiveOntology();
OWLOntologyManager manager = owlEditorKit.getModelManager().getOWLOntologyManager();
OWLOntologyFormat format = manager.getOntologyFormat(activeOntology);
------------------------------

//Set selected values in given list
public void setSelectedValues(Set<OWLRelation> owlRelations, boolean shouldScroll) {
    getSelectionModel().clearSelection();
    if (getSelectionMode() == ListSelectionModel.MULTIPLE_INTERVAL_SELECTION){
        int firstIndex = -1;
        for (int i=0; i<getModel().getSize(); i++){
            if (owlRelations.contains(getModel().getElementAt(i))){
                getSelectionModel().addSelectionInterval(i, i);
                if (firstIndex == -1){
                    firstIndex = i;
                }
            }
        }
        if (shouldScroll && firstIndex != -1){
            scrollRectToVisible(new Rectangle(getCellBounds(firstIndex, firstIndex)));
        }
    }
}

//Get selected objects in given list
@SuppressWarnings("unchecked")
public java.util.List<OWLRelation> getSelectedOWLObjects(){
    List<OWLRelation> sel = new ArrayList<OWLRelation>();
    for (Object o : getSelectedValues()){
        sel.add((OWLRelation) o);
    }
    return sel;
}
}

-------------------------------
if (getOWLWorkspace().getOWLSelectionModel().getSelectedObject() instanceof OWLClass){
    refill();
----------------------------
OWLClass selectedClass = getOWLWorkspace().getOWLSelectionModel().getLastSelectedClass();
setEnabled(selectedClass != null &&
      getOWLModelManager().getOWLHierarchyManager().getOWLClassHierarchyProvider().getChildren(selectedClass).size() > 1);
---------------------------------------
OWLClass cls = getOWLWorkspace().getOWLSelectionModel().getLastSelectedClass();
// TODO: Push into OWLAPI
Set<OWLClass> subClses = getOWLModelManager().getOWLHierarchyManager().getOWLClassHierarchyProvider().getChildren(cls);
OWLClassExpression coveringDesc = getOWLDataFactory().getOWLObjectUnionOf(subClses);
OWLSubClassOfAxiom ax = getOWLDataFactory().getOWLSubClassOfAxiom(cls, coveringDesc);
getOWLModelManager().applyChange(new AddAxiom(getOWLModelManager().getActiveOntology(), ax));

------------------------------------
Set<OWLLiteral> annotations = new HashSet<>();
for (OWLAnnotation label : labelAnnotations) {
		System.out.println("label = " + label.getValue());
		annotations.add((OWLLiteral) label.getValue());
-----------------------------------------------------------
Stream<OWLAnnotation> annotations = getAnnotations(entity, ontology);
for (OWLAnnotation annotation : annotations) {
	System.out.println("annotation = " + annotation);
?//}


---------------------------------------------

OWLOntology ontology = getOWLModelManager().getActiveOntology();
System.out.println("ontology = " + ontology);

Set<OWLClass> concepts = getOWLModelManager().getActiveOntology().getClassesInSignature();

for (OWLClass concept : concepts) {
	System.out.println("concept = " + concept.getIRI().getShortForm());
	Set<OWLAnnotation> annotations = concept.getAnnotations(ontology);
	for (OWLAnnotation annotation : annotations) {
		System.out.println("annotation = " + annotation);
	}
}

-----------------------------------------------

StringBuilder message = new StringBuilder("Signature_Keep_All 13 ............................");		
JOptionPane.showMessageDialog(getOWLWorkspace(), message.toString());

Set<OWLClass> classes = getOWLModelManager().getActiveOntology().getClassesInSignature();

for (OWLClass classA : classes) {
	System.out.println("classA = " + classA.getIRI().getShortForm());
}

--------------------------------

Set<OWLAnnotation> annotations = classA.getAnnotations(Config.getOntology());
for (OWLAnnotation annotation : annotations) {
	
	OWLLiteral literal = (OWLLiteral) annotation.getValue();
	String literalString = literal.getLiteral();

	if (literalString.contains("]ts-")) {
		Set<OWLAxiom> axiomsToRemove = new HashSet<OWLAxiom>();
		OWLAxiom ax = Config.getFactory().getOWLAnnotationAssertionAxiom(classA.getIRI(), annotation);
        axiomsToRemove.add(ax);
        Config.getManager().removeAxioms(Config.getOntology(), axiomsToRemove);
	}
}
String commentAnnoString = " ";
if (ts.contains("forget")) { 
	commentAnnoString = "]ts-individual-forget"; 
}
else { 
	commentAnnoString = "]ts-individual-keep"; 
}
OWLAnnotation commentAnnotation = Config.getFactory().getOWLAnnotation(Config.getFactory().getRDFSComment(),
		Config.getFactory().getOWLLiteral(commentAnnoString));
OWLAxiom ax = Config.getFactory().getOWLAnnotationAssertionAxiom(classA.getIRI(), commentAnnotation);
Config.getManager().applyChange(new AddAxiom(Config.getOntology(), ax));


*/